#!/bin/bash

# Initialize Email Agent Data
# This script creates the data directory and initializes mock data

echo "Initializing Email Agent data..."

# Create data directory
mkdir -p data

# Initialize empty data files if they don't exist
if [ ! -f data/emails.json ]; then
  echo "[]" > data/emails.json
  echo "Created data/emails.json"
fi

if [ ! -f data/prompts.json ]; then
  echo "[]" > data/prompts.json
  echo "Created data/prompts.json"
fi

if [ ! -f data/drafts.json ]; then
  echo "[]" > data/drafts.json
  echo "Created data/drafts.json"
fi

echo "Data initialization complete!"
echo "Starting development server..."

npm run dev
