// TypeScript initialization script for data directory
import fs from "fs"
import path from "path"

const dataDir = path.join(process.cwd(), "data")

// Ensure data directory exists
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true })
  console.log("Created data directory")
}

// Initialize empty JSON files
const files = ["emails.json", "prompts.json", "drafts.json"]

files.forEach((file) => {
  const filePath = path.join(dataDir, file)
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, "[]")
    console.log(`Created ${file}`)
  }
})

console.log("Data directory initialized successfully!")
