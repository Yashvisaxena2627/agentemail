"use client"

import { useEffect } from "react"
import { initializeMockData } from "@/lib/storage"
import { mockEmails, defaultPrompts } from "@/lib/mock-data"

export function useInitData() {
  useEffect(() => {
    // Initialize mock data in memory storage on app load
    try {
      initializeMockData(mockEmails, defaultPrompts)
    } catch (error) {
      console.error("Failed to initialize mock data:", error)
    }
  }, [])
}
