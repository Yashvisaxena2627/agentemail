// Mock inbox data initialization
import type { Email, PromptConfig } from "./types"

export const mockEmails: Email[] = [
  {
    id: "1",
    from: "team@company.com",
    to: "you@example.com",
    subject: "Q4 Project Kickoff Meeting - Next Tuesday",
    body: "Hi,\n\nWe have scheduled the Q4 project kickoff for next Tuesday at 2 PM. Please review the attached agenda and come prepared to discuss timelines.\n\nLooking forward to seeing you there.\n\nBest,\nProject Manager",
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    category: "Important",
    isRead: false,
    actionItems: [
      {
        id: "a1",
        task: "Review Q4 project agenda",
        deadline: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
        priority: "high",
      },
    ],
  },
  {
    id: "2",
    from: "newsletter@techblog.com",
    to: "you@example.com",
    subject: "This Week in Tech - November Updates",
    body: "Here are the top tech stories from this week...",
    timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    category: "Newsletter",
    isRead: true,
  },
  {
    id: "3",
    from: "client@customer.com",
    to: "you@example.com",
    subject: "Proposal Review - Need Feedback by Friday",
    body: "Hi,\n\nI've attached the proposal for your review. Can you provide feedback by Friday EOD? We need to present this to the board on Monday.\n\nThanks!",
    timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    category: "To-Do",
    isRead: false,
    actionItems: [
      {
        id: "a2",
        task: "Review and provide feedback on proposal",
        deadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
        priority: "high",
      },
    ],
  },
  {
    id: "4",
    from: "noreply@promotional.com",
    to: "you@example.com",
    subject: "LIMITED TIME: 50% OFF Everything!",
    body: "Don't miss out! Use code SAVE50 at checkout...",
    timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    category: "Spam",
    isRead: true,
  },
  {
    id: "5",
    from: "hr@company.com",
    to: "you@example.com",
    subject: "Annual Review Scheduled",
    body: "Your annual review has been scheduled for November 30th at 3 PM with your manager.",
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    category: "Important",
    isRead: false,
    actionItems: [
      {
        id: "a3",
        task: "Prepare for annual review",
        deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        priority: "medium",
      },
    ],
  },
  {
    id: "6",
    from: "support@service.com",
    to: "you@example.com",
    subject: "Your ticket #12345 has been resolved",
    body: "Your support ticket has been marked as resolved. If you need further assistance, please reply to this email.",
    timestamp: new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString(),
    category: "Newsletter",
    isRead: true,
  },
  {
    id: "7",
    from: "colleague@company.com",
    to: "you@example.com",
    subject: "RE: Code Review - PR #456",
    body: "Thanks for reviewing my code. I've addressed your comments. Can you take another look when you get a chance?",
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    category: "To-Do",
    isRead: false,
    actionItems: [
      {
        id: "a4",
        task: "Review code changes in PR #456",
        deadline: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
        priority: "medium",
      },
    ],
  },
  {
    id: "8",
    from: "marketing@company.com",
    to: "you@example.com",
    subject: "Campaign Performance Report",
    body: "The latest marketing campaign achieved 2.5M impressions and a 3.2% CTR.",
    timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    category: "Newsletter",
    isRead: true,
  },
  {
    id: "9",
    from: "sales@vendor.com",
    to: "you@example.com",
    subject: "New enterprise features now available",
    body: "Check out our latest feature rollout...",
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    category: "Spam",
    isRead: true,
  },
  {
    id: "10",
    from: "manager@company.com",
    to: "you@example.com",
    subject: "OKR Discussion - Please submit by end of week",
    body: "Please submit your proposed OKRs for next quarter by Friday. We'll discuss in our 1:1 next week.",
    timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
    category: "Important",
    isRead: false,
    actionItems: [
      {
        id: "a5",
        task: "Submit proposed OKRs for next quarter",
        deadline: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
        priority: "high",
      },
    ],
  },
]

export const defaultPrompts: PromptConfig[] = [
  {
    id: "prompt-1",
    name: "Email Categorization",
    type: "categorization",
    prompt: `Categorize the following email into ONE of these categories: Important, To-Do, Newsletter, or Spam.

Important emails are high-priority, need immediate attention, or are critical business communications.
To-Do emails contain direct requests requiring user action or decisions.
Newsletter emails are informational updates, reports, or subscriptions.
Spam emails are promotional, unsolicited, or low-priority marketing.

Email:
---
{email_content}
---

Respond with ONLY the category name, nothing else.`,
    description: "Automatically categorizes incoming emails",
    isDefault: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: "prompt-2",
    name: "Action Item Extraction",
    type: "action_extraction",
    prompt: `Extract all action items from the following email. For each action item, identify the task and deadline if mentioned.

Email:
---
{email_content}
---

Respond in JSON format:
{
  "actions": [
    {"task": "...", "deadline": "...", "priority": "high|medium|low"},
    ...
  ]
}

If no actions are found, respond with {"actions": []}.`,
    description: "Extracts tasks and deadlines from emails",
    isDefault: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: "prompt-3",
    name: "Meeting Request Reply",
    type: "auto_reply",
    prompt: `This is a meeting request email. Draft a professional reply confirming availability and asking for the agenda. Keep it concise and friendly.

Email:
---
{email_content}
---

Draft reply:`,
    description: "Generates replies for meeting requests",
    isDefault: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: "prompt-4",
    name: "Email Summary",
    type: "custom",
    prompt: `Summarize the following email in 2-3 sentences, highlighting the main points and any required actions.

Email:
---
{email_content}
---

Summary:`,
    description: "Creates concise email summaries",
    isDefault: true,
    createdAt: new Date().toISOString(),
  },
]
