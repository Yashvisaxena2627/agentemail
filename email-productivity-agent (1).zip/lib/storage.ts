// Client-side mock storage using localStorage and in-memory fallback
import type { Email, PromptConfig, Draft } from "./types"

// In-memory storage as fallback
const memoryStore = {
  emails: [] as Email[],
  prompts: [] as PromptConfig[],
  drafts: [] as Draft[],
}

// This works in both browser and server contexts

function getLocalStorageKey(type: string): string {
  return `email-agent-${type}`
}

// Email operations
export function getEmails(): Email[] {
  try {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(getLocalStorageKey("emails"))
      return stored ? JSON.parse(stored) : memoryStore.emails
    }
  } catch (error) {
    console.error("Error reading emails from storage:", error)
  }
  return memoryStore.emails
}

export function saveEmails(emails: Email[]): void {
  try {
    memoryStore.emails = emails
    if (typeof window !== "undefined") {
      localStorage.setItem(getLocalStorageKey("emails"), JSON.stringify(emails))
    }
  } catch (error) {
    console.error("Error saving emails:", error)
  }
}

export function addEmail(email: Email): void {
  const emails = getEmails()
  emails.push(email)
  saveEmails(emails)
}

export function updateEmail(id: string, updates: Partial<Email>): void {
  const emails = getEmails()
  const index = emails.findIndex((e) => e.id === id)
  if (index !== -1) {
    emails[index] = { ...emails[index], ...updates }
    saveEmails(emails)
  }
}

// Prompt operations
export function getPrompts(): PromptConfig[] {
  try {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(getLocalStorageKey("prompts"))
      return stored ? JSON.parse(stored) : memoryStore.prompts
    }
  } catch (error) {
    console.error("Error reading prompts from storage:", error)
  }
  return memoryStore.prompts
}

export function savePrompts(prompts: PromptConfig[]): void {
  try {
    memoryStore.prompts = prompts
    if (typeof window !== "undefined") {
      localStorage.setItem(getLocalStorageKey("prompts"), JSON.stringify(prompts))
    }
  } catch (error) {
    console.error("Error saving prompts:", error)
  }
}

export function addPrompt(prompt: PromptConfig): void {
  const prompts = getPrompts()
  prompts.push(prompt)
  savePrompts(prompts)
}

export function updatePrompt(id: string, updates: Partial<PromptConfig>): void {
  const prompts = getPrompts()
  const index = prompts.findIndex((p) => p.id === id)
  if (index !== -1) {
    prompts[index] = { ...prompts[index], ...updates }
    savePrompts(prompts)
  }
}

// Draft operations
export function getDrafts(): Draft[] {
  try {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(getLocalStorageKey("drafts"))
      return stored ? JSON.parse(stored) : memoryStore.drafts
    }
  } catch (error) {
    console.error("Error reading drafts from storage:", error)
  }
  return memoryStore.drafts
}

export function saveDrafts(drafts: Draft[]): void {
  try {
    memoryStore.drafts = drafts
    if (typeof window !== "undefined") {
      localStorage.setItem(getLocalStorageKey("drafts"), JSON.stringify(drafts))
    }
  } catch (error) {
    console.error("Error saving drafts:", error)
  }
}

export function addDraft(draft: Draft): void {
  const drafts = getDrafts()
  drafts.push(draft)
  saveDrafts(drafts)
}

export function updateDraft(id: string, updates: Partial<Draft>): void {
  const drafts = getDrafts()
  const index = drafts.findIndex((d) => d.id === id)
  if (index !== -1) {
    drafts[index] = { ...drafts[index], ...updates }
    saveDrafts(drafts)
  }
}

export function deleteDraft(id: string): void {
  const drafts = getDrafts()
  const filtered = drafts.filter((d) => d.id !== id)
  saveDrafts(filtered)
}

// Initialize with mock data
export function initializeMockData(mockEmails: Email[], mockPrompts: PromptConfig[]): void {
  if (getEmails().length === 0) {
    saveEmails(mockEmails)
  }
  if (getPrompts().length === 0) {
    savePrompts(mockPrompts)
  }
}
