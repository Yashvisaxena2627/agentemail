import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function safeJsonParse(json: string, fallback: any = null) {
  try {
    return JSON.parse(json)
  } catch {
    return fallback
  }
}

export function safeJsonStringify(obj: any, fallback = "{}") {
  try {
    return JSON.stringify(obj)
  } catch {
    return fallback
  }
}
