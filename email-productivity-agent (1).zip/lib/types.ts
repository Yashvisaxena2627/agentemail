// Core type definitions for the email agent system

export interface Email {
  id: string
  from: string
  to: string
  subject: string
  body: string
  timestamp: string
  category?: string
  actionItems?: ActionItem[]
  isRead: boolean
}

export interface ActionItem {
  id: string
  task: string
  deadline?: string
  priority?: "high" | "medium" | "low"
  completed?: boolean
}

export interface PromptConfig {
  id: string
  name: string
  type: "categorization" | "action_extraction" | "auto_reply" | "custom"
  prompt: string
  description?: string
  isDefault: boolean
  createdAt: string
}

export interface Draft {
  id: string
  emailId?: string
  subject: string
  body: string
  tone?: string
  category?: string
  actionItems?: ActionItem[]
  createdAt: string
  status: "draft" | "archived"
}

export interface InboxState {
  emails: Email[]
  prompts: PromptConfig[]
  drafts: Draft[]
  selectedEmailId?: string
}

export interface LLMRequest {
  content: string
  prompt: string
  model?: string
}

export interface LLMResponse {
  text: string
  parsed?: Record<string, unknown>
}

export interface SentEmail extends Email {
  recipientEmail?: string
  sentAt: string
  type: "sent" | "received"
}
