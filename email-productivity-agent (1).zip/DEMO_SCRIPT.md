# Demo Video Script (5-10 minutes)

## Opening (30 seconds)

"Welcome to the Email Productivity Agent! A powerful AI-driven system for managing your inbox, categorizing emails, extracting action items, and generating smart replies.

In this demo, I'll show you how to:
1. View and organize emails
2. Use AI to process emails
3. Create custom prompts
4. Generate email drafts"

## Part 1: Dashboard Overview (1 minute)

**Show:**
- Header with Email Agent branding
- Three main tabs: Inbox, Prompts, Agent Chat
- Explain the color-coded design

**Say:**
"The app has three main sections. The Inbox shows your emails with automatic categorization using color coding. The Prompts tab lets you customize AI behavior. And the Agent Chat is where you interact with the AI assistant."

## Part 2: Inbox Management (2 minutes)

**Actions:**
1. Click "Inbox" tab
2. Show the email list on the left
3. Click an email to view details
4. Show the color-coded categories:
   - Red = Important
   - Blue = To-Do
   - Purple = Newsletter
   - Gray = Spam

**Say:**
"The inbox shows all your emails. Each email is automatically categorized based on content. I can click any email to see the full details, including sender, subject, timestamp, and body content. Notice how action items are automatically extracted - you can see tasks with deadlines and priority levels."

**Demo:**
- Mark email as read
- Copy email content
- Show action items
- Explain categories

## Part 3: Prompts Configuration (2 minutes)

**Actions:**
1. Click "Prompts" tab
2. Show 4 default prompt templates
3. Explain each one:
   - Email Categorization
   - Action Item Extraction
   - Meeting Request Reply
   - Email Summary
4. Click edit on one to show prompt text
5. Click "New Prompt" to create custom one

**Say:**
"The Prompts tab shows four built-in templates that control how the AI processes emails. You can edit these or create your own custom prompts using the `{email_content}` placeholder. Let me create a custom prompt..."

**Demo Creation:**
1. Click "New Prompt"
2. Name: "Sales Follow-up"
3. Type: "auto_reply"
4. Prompt text: "Draft a professional sales follow-up email"
5. Click "Save"
6. Show it in the prompt list

## Part 4: AI Agent Chat (3 minutes)

**Actions:**
1. Go to "Agent Chat" tab
2. Select an email from inbox
3. Ask several questions:
   - "Summarize this email"
   - "What action items do I need?"
   - "Draft a professional reply"
4. Show chat interface
5. Show saved drafts

**Say:**
"Now let's use the AI agent. I'll select an email and ask questions about it. The AI understands the email context and can help me summarize, extract tasks, or draft responses."

**Demo:**
- Type: "Summarize this email in one sentence"
- Show response in chat
- Type: "What's my action item here?"
- Show response
- Type: "Draft a professional reply asking for more details"
- Show drafted response

**Highlight:**
- Chat bubbles (user vs assistant)
- Real-time responses
- "Thinking..." indicator
- Saved drafts in sidebar

## Part 5: Draft Saving (1 minute)

**Show:**
1. Look at "Saved Drafts" section
2. See previously saved drafts
3. Click "Use as Template"
4. Explain drafts are never auto-sent

**Say:**
"All generated drafts are safely saved in the sidebar. You can review them, use them as templates, or refine them before sending. The AI never sends emails automatically - it's all under your control."

## Part 6: Customization Demonstration (1 minute)

**Show:**
- Edit a default prompt
- Modify the text slightly
- Save changes
- Use modified prompt in chat

**Say:**
"One of the powerful features is prompt customization. You can modify these prompts to match your specific needs. Any changes you make are instantly available in the Agent Chat."

## Closing (30 seconds)

"The Email Productivity Agent helps you:
- Organize emails automatically
- Extract important information
- Draft responses quickly
- Save time on email management
- Control AI behavior with custom prompts

All your data stays private - it's stored locally in your browser. Get started by going to localhost:3000 and exploring the features yourself!"

## Key Points to Emphasize

✨ **Highlight These:**
1. **Automatic Categorization** - Shows color-coded system
2. **AI Power** - Real-time responses in chat
3. **Customization** - Create own prompts
4. **Safety** - Never auto-sends, local storage
5. **User Control** - All actions user-initiated

## B-Roll Ideas

📹 **Film These:**
- Email list scrolling
- Clicking through emails
- Reading AI responses
- Creating new prompt
- Saving/using drafts
- Category filters
- Dark theme UI

## Sample Dialogue

**Alternative script if going longer:**

"Have you ever spent too much time managing emails? The Email Productivity Agent uses AI to automate your email workflow. Watch as I show you its key features..."

[Demo each section as above]

"Whether you're managing a large inbox or need to prioritize emails, this tool helps you stay organized and respond faster. Best of all, your data stays private and all processing happens locally in your browser."

## Tips for Recording

1. **Quality Settings**
   - 1080p resolution
   - 30 fps
   - Zoom to 125% for readability
   - Use dark mode for visual appeal

2. **Pacing**
   - Slow down for transitions
   - Pause after showing each feature
   - Let responses fully load before moving on

3. **Audio**
   - Use clear, calm voice
   - Speak directly to camera
   - Background noise reduction

4. **Editing**
   - Add title card at start
   - Add feature labels/captions
   - Slow down important demos
   - Add music (optional)
   - 5-10 minute total length

## Recording Tools

- **Screen Capture**: OBS Studio, ScreenFlow, ShareX
- **Editing**: DaVinci Resolve (free), Adobe Premiere Pro
- **Audio**: Audacity (free), Adobe Audition
- **Upload**: YouTube, Vimeo, Loom

---

**Good luck with your demo!** 🎬
