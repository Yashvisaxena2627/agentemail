# Email Productivity Agent

An intelligent, prompt-driven email management system built with Next.js and AI. This application processes your inbox, categorizes emails, extracts action items, and provides an AI-powered chat interface for email management.

## Features

✨ **Core Functionality**
- 📧 **Email Inbox Management** - View, organize, and manage emails with automatic categorization
- 🤖 **AI-Powered Email Processing** - Automatic email categorization and action item extraction using LLM
- 💬 **Email Agent Chat** - Ask questions about emails, get summaries, and draft replies
- 📝 **Draft Generation** - Create and save email drafts with AI assistance
- ⚙️ **Prompt Configuration** - Create, edit, and manage custom prompts to guide AI behavior
- 💾 **Safe Drafts** - All emails are saved as drafts; nothing is sent automatically

## Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn
- OpenAI API key (for AI features)

### Installation

1. **Clone or Download the Project**
   \`\`\`bash
   git clone <repository-url>
   cd email-agent
   \`\`\`

2. **Install Dependencies**
   \`\`\`bash
   npm install
   \`\`\`

3. **Set Environment Variables**
   Create a `.env.local` file in the root directory:
   \`\`\`
   OPENAI_API_KEY=sk_your_key_here
   NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000
   \`\`\`

4. **Run Development Server**
   \`\`\`bash
   npm run dev
   \`\`\`

5. **Open in Browser**
   Navigate to `http://localhost:3000`

## How to Use

### 1. Loading the Mock Inbox

The application automatically loads 10 sample emails on first run. You'll see:
- Meeting requests
- To-do items
- Newsletters
- Spam emails

These are stored in `lib/mock-data.ts` and automatically initialized in the `data/emails.json` file.

### 2. Email Inbox View

**Navigate to the "Inbox" tab to:**
- View all emails in a list
- Click to view full email details
- Mark emails as read/unread
- See automatically categorized emails
- View extracted action items

### 3. Configure Prompts

**Navigate to the "Prompts" tab to:**

**Default Prompts Included:**
- **Email Categorization** - Automatically sorts emails into Important, To-Do, Newsletter, or Spam
- **Action Item Extraction** - Identifies tasks and deadlines
- **Meeting Request Reply** - Drafts professional replies
- **Email Summary** - Creates concise summaries

**To Create a Custom Prompt:**
1. Click "New Prompt"
2. Fill in the form:
   - **Name**: Descriptive name for your prompt
   - **Type**: Choose categorization, action extraction, auto-reply, or custom
   - **Description**: What does this prompt do?
   - **Prompt Text**: Your prompt (use `{email_content}` as placeholder)
3. Click "Save Prompt"

### 4. Using the Email Agent Chat

**Navigate to the "Agent Chat" tab to:**
- Select an email (or chat generally)
- Ask questions like:
  - "Summarize this email"
  - "What tasks do I need to do?"
  - "Draft a professional reply"
  - "Is this email important?"
- View AI responses
- Save drafts from conversation

### 5. Managing Drafts

- All AI-generated email responses are saved as **drafts**
- Drafts are never automatically sent
- View saved drafts in the right sidebar of the Email Agent
- Use drafts as templates for new emails

## Project Structure

\`\`\`
.
├── app/
│   ├── page.tsx                 # Main dashboard
│   ├── layout.tsx               # Root layout
│   ├── globals.css              # Global styles & theme
│   ├── api/
│   │   ├── emails/route.ts       # Email CRUD endpoints
│   │   ├── prompts/route.ts      # Prompt CRUD endpoints
│   │   ├── drafts/route.ts       # Draft CRUD endpoints
│   │   ├── process-email/route.ts # LLM email processing
│   │   └── chat/route.ts         # Email agent chat
│   └── data/                     # JSON storage (auto-created)
│       ├── emails.json
│       ├── prompts.json
│       └── drafts.json
├── components/
│   ├── inbox.tsx                # Email list & detail view
│   ├── email-list.tsx           # Email list component
│   ├── email-detail.tsx         # Email detail view
│   ├── prompt-configurator.tsx  # Prompt management UI
│   ├── prompt-editor.tsx        # Prompt edit form
│   ├── email-agent.tsx          # Chat interface
│   └── ui/                       # UI components
│       ├── button.tsx
│       ├── input.tsx
│       ├── textarea.tsx
│       ├── badge.tsx
│       └── card.tsx
├── lib/
│   ├── types.ts                 # TypeScript interfaces
│   ├── storage.ts               # File-based storage layer
│   ├── mock-data.ts             # Sample emails & default prompts
│   └── utils.ts                 # Utility functions
├── public/                       # Static assets
└── package.json

\`\`\`

## Configuration

### Environment Variables

Create `.env.local` in the project root:

\`\`\`env
# Required for AI features
OPENAI_API_KEY=your_openai_api_key

# Optional
NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000
\`\`\`

### Default Prompts

Default prompts are located in `lib/mock-data.ts`. To add more:

\`\`\`typescript
export const defaultPrompts: PromptConfig[] = [
  {
    id: 'prompt-id',
    name: 'Prompt Name',
    type: 'categorization', // or action_extraction, auto_reply, custom
    prompt: 'Your prompt here. Use {email_content} as placeholder.',
    description: 'What this prompt does',
    isDefault: true,
    createdAt: new Date().toISOString(),
  },
  // Add more prompts...
];
\`\`\`

### Customizing the UI Theme

Edit `app/globals.css` to change colors and theme:

\`\`\`css
:root {
  --primary: oklch(0.5 0.2 250);
  --background: oklch(0.08 0 0);
  --foreground: oklch(0.95 0 0);
  /* ... other variables ... */
}
\`\`\`

## API Endpoints

### Emails
- `GET /api/emails` - Get all emails
- `PUT /api/emails` - Update an email

### Prompts
- `GET /api/prompts` - Get all prompts
- `POST /api/prompts` - Create new prompt
- `PUT /api/prompts` - Update prompt

### Drafts
- `GET /api/drafts` - Get all drafts
- `POST /api/drafts` - Create draft
- `PUT /api/drafts` - Update draft
- `DELETE /api/drafts?id=<id>` - Delete draft

### Processing
- `POST /api/process-email` - Process email with LLM
  \`\`\`json
  {
    "emailContent": "email text",
    "prompt": "your prompt",
    "action": "categorize"
  }
  \`\`\`

- `POST /api/chat` - Chat with email agent
  \`\`\`json
  {
    "query": "user question",
    "emailContent": "optional email text",
    "context": "optional context"
  }
  \`\`\`

## Email Categorization

Emails are automatically categorized into:
- **Important** - High-priority, urgent, or critical business communications
- **To-Do** - Contains direct requests or action items
- **Newsletter** - Informational updates, reports, or subscriptions
- **Spam** - Promotional or unsolicited messages

## Examples

### Example: Create Custom Categorization Prompt

\`\`\`
Categorize this email by its urgency level: URGENT, HIGH, MEDIUM, or LOW.
Consider factors like deadlines, language tone, and business impact.

Email:
---
{email_content}
---

Response: [URGENCY_LEVEL]
\`\`\`

### Example: Extract Specific Information

\`\`\`
Extract the following from this email in JSON format:
- sender_company (from email domain)
- main_topic
- requested_actions (list)
- deadline (if mentioned)

Email:
---
{email_content}
---

JSON Response:
\`\`\`

### Example: Generate Professional Draft

\`\`\`
Generate a professional but friendly reply to this email. 
If it's a meeting request, ask for the agenda.
If it's a question, provide a helpful response.
Keep it concise (under 5 sentences).

Email:
---
{email_content}
---

Draft Reply:
\`\`\`

## Data Storage

All data is stored in JSON files in the `data/` directory:

- `data/emails.json` - Stores all emails
- `data/prompts.json` - Stores all prompts
- `data/drafts.json` - Stores all drafts

These files are created automatically on first run.

## Troubleshooting

### "Failed to fetch emails"
- Ensure the `data/` directory exists and is writable
- Check file permissions
- Restart the development server

### "Failed to process email with LLM"
- Verify your `OPENAI_API_KEY` is valid
- Check that your OpenAI account has available credits
- View the server logs for specific error messages

### "No emails appearing"
- Clear `data/emails.json` and restart the server
- Mock data will reinitialize automatically

### Chat not responding
- Verify your OpenAI API key in `.env.local`
- Check browser console for error messages
- Ensure you have an active internet connection

## Best Practices

1. **Custom Prompts** - Create specific prompts for your workflow
2. **Regular Reviews** - Review categorized emails to improve accuracy
3. **Prompt Refinement** - Adjust prompts based on results
4. **Draft Reviews** - Always review AI-generated drafts before use
5. **Backups** - Regularly backup your `data/` directory

## Technology Stack

- **Frontend**: React 19, Next.js 16
- **Styling**: Tailwind CSS v4, shadcn/ui
- **AI**: Vercel AI SDK, OpenAI
- **Storage**: File-based JSON
- **Language**: TypeScript

## Development

### Running Tests
\`\`\`bash
npm run test
\`\`\`

### Building for Production
\`\`\`bash
npm run build
npm run start
\`\`\`

### Code Style
\`\`\`bash
npm run lint
\`\`\`

## License

MIT - Feel free to use this project for personal or commercial purposes.

## Support

For issues, questions, or feature requests, open an issue in the repository or contact support.

---

**Happy emailing!** 🚀
\`\`\`

```json file="" isHidden
