# Email Productivity Agent - Deployment Guide

## Development Setup (Local)

### Prerequisites
- Node.js 18+
- npm or yarn
- OpenAI API key

### Quick Start
\`\`\`bash
git clone <repo-url>
cd email-agent
npm install

# Create .env.local
echo "OPENAI_API_KEY=sk_your_key_here" > .env.local

# Run locally
npm run dev
\`\`\`

Visit `http://localhost:3000`

---

## Deployment Options

### Option 1: Vercel (Recommended - 1 click)

1. **Push to GitHub**
   \`\`\`bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   \`\`\`

2. **Deploy to Vercel**
   - Go to https://vercel.com
   - Click "New Project"
   - Select your GitHub repository
   - Click "Import"

3. **Configure Environment Variables**
   - In Vercel dashboard: Settings → Environment Variables
   - Add: `OPENAI_API_KEY=sk_your_key_here`
   - Click "Deploy"

4. **Your app is live!**
   - Vercel provides a .vercel.app URL
   - You can add a custom domain

**Pros:** 
- One-click deployment
- Automatic HTTPS
- Auto-scaling
- Free tier available

**Cons:**
- File storage may not persist across deployments (see below)

### Option 2: Docker + Any Cloud

1. **Create Dockerfile**
   \`\`\`dockerfile
   FROM node:18-alpine
   WORKDIR /app
   COPY package*.json ./
   RUN npm install
   COPY . .
   RUN npm run build
   EXPOSE 3000
   CMD ["npm", "start"]
   \`\`\`

2. **Create docker-compose.yml**
   \`\`\`yaml
   version: '3'
   services:
     web:
       build: .
       ports:
         - "3000:3000"
       environment:
         - OPENAI_API_KEY=${OPENAI_API_KEY}
   \`\`\`

3. **Deploy to:**
   - **Heroku**: `git push heroku main`
   - **DigitalOcean**: Use App Platform
   - **AWS**: Use Elastic Beanstalk or EC2
   - **Railway**: Connect GitHub repo

### Option 3: Self-Hosted (VPS)

1. **Rent a VPS**
   - DigitalOcean ($6/month)
   - Linode
   - AWS EC2
   - Hetzner

2. **Setup Node.js**
   \`\`\`bash
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   \`\`\`

3. **Deploy**
   \`\`\`bash
   git clone <repo>
   cd email-agent
   npm install
   npm run build
   
   # Using PM2 for background process
   npm install -g pm2
   pm2 start npm --name "email-agent" -- start
   pm2 startup
   pm2 save
   \`\`\`

4. **Add Nginx Reverse Proxy**
   \`\`\`nginx
   server {
     listen 80;
     server_name yourdomain.com;
     
     location / {
       proxy_pass http://localhost:3000;
     }
   }
   \`\`\`

---

## Important: Data Persistence

### Issue with Vercel & File Storage

Vercel's file system is ephemeral - files created at runtime don't persist.

### Solutions

#### Solution 1: Use Database (Recommended for Production)

Replace file storage with:
- **Supabase** (PostgreSQL)
- **MongoDB Atlas** (NoSQL)
- **Neon** (PostgreSQL)
- **PlanetScale** (MySQL)

Example with Supabase:
\`\`\`typescript
// Instead of lib/storage.ts
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(url, key);

export async function getEmails() {
  const { data } = await supabase.from('emails').select('*');
  return data || [];
}
\`\`\`

#### Solution 2: Use Object Storage

Store files in:
- **Vercel Blob** (if on Vercel)
- **AWS S3**
- **Google Cloud Storage**
- **DigitalOcean Spaces**

#### Solution 3: Self-Host

Use file system on a VPS with persistent storage.

---

## Production Checklist

- [ ] Environment variables configured
- [ ] API keys secured (never commit .env)
- [ ] Data persistence solution implemented
- [ ] Database backups enabled
- [ ] Error logging configured
- [ ] Rate limiting implemented
- [ ] CORS configured properly
- [ ] HTTPS enabled
- [ ] Performance optimized
- [ ] Security headers set
- [ ] Monitoring/alerting setup

---

## Environment Variables

### Required
\`\`\`env
OPENAI_API_KEY=sk_...
\`\`\`

### Optional
\`\`\`env
NODE_ENV=production
NEXT_PUBLIC_SITE_URL=https://yourdomain.com
LOG_LEVEL=info
\`\`\`

---

## Performance Optimization

1. **Enable Caching**
   \`\`\`typescript
   // In API routes
   response.headers.set('Cache-Control', 'public, s-maxage=3600');
   \`\`\`

2. **Database Indexing**
   - Index email IDs
   - Index timestamps
   - Index categories

3. **API Response Caching**
   - Cache email list
   - Cache prompt templates
   - Invalidate on updates

4. **Frontend Optimization**
   - Lazy load email details
   - Paginate email list
   - Image optimization

---

## Monitoring & Logging

### CloudWatch (AWS)
\`\`\`typescript
import winston from 'winston';

const logger = winston.createLogger({
  defaultMeta: { service: 'email-agent' },
});

logger.info('Email processed', { emailId: '123' });
\`\`\`

### Sentry (Error Tracking)
\`\`\`typescript
import * as Sentry from "@sentry/nextjs";

Sentry.captureException(error);
\`\`\`

---

## Cost Estimates

### Vercel
- **Free**: 100 deployments/month
- **Pro**: $20/month for production use

### OpenAI API
- **GPT-4O Mini**: ~$0.00015 per 1K tokens
- **Average email**: 500-1000 tokens
- **Estimate**: $0.0001-0.0002 per email processed

### Database (Supabase Free)
- **Free**: 500MB storage, good for thousands of emails
- **Pro**: $25/month for 100GB

### Total Monthly Cost
- **Development**: $0 (free tier)
- **Small Production**: $20-30/month
- **Large Production**: $50-100/month

---

## Common Issues & Solutions

### Issue: Data Lost After Deployment

**Cause:** Vercel's ephemeral file system

**Solution:** Migrate to database (see above)

### Issue: API Timeout

**Cause:** LLM requests taking too long

**Solution:**
\`\`\`typescript
// Add timeout
const controller = new AbortController();
const timeoutId = setTimeout(() => controller.abort(), 30000);
\`\`\`

### Issue: High API Costs

**Cause:** Too many LLM calls

**Solution:**
- Cache results
- Use cheaper models (GPT-4O mini)
- Implement rate limiting
- Batch process emails

### Issue: Memory Issues

**Cause:** Loading too many emails into memory

**Solution:**
- Implement pagination
- Stream large datasets
- Use database queries with limits

---

## Rollback & Updates

### Zero-Downtime Deployment

**Vercel:** Automatic with each push

**Self-Hosted with PM2:**
\`\`\`bash
pm2 start app.js
pm2 reload app  # Graceful reload
\`\`\`

### Database Migrations

\`\`\`typescript
// Create migration file
// scripts/migrations/001_initial_schema.sql

// Run migration
npm run migrate
\`\`\`

---

## Security Hardening

\`\`\`typescript
// app/api/emails/route.ts
import rateLimit from 'express-rate-limit';

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // 100 requests per window
});

export async function GET(request) {
  await limiter(request);
  // ... rest of code
}
\`\`\`

---

## Support & Troubleshooting

For deployment issues:
1. Check Vercel/server logs
2. Verify environment variables
3. Test API endpoints locally
4. Check database connectivity
5. Review error messages in console

---

**Ready to deploy?** Choose your platform and follow the steps above!
