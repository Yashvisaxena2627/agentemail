"use client"

import type React from "react"
import { useState } from "react"
import type { PromptConfig } from "@/lib/types"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Textarea } from "./ui/textarea"
import { AlertCircle } from "lucide-react"

interface PromptEditorProps {
  prompt?: PromptConfig
  onSave: (prompt: Partial<PromptConfig>) => void
  onCancel: () => void
}

const promptTypes = ["categorization", "action_extraction", "auto_reply", "custom"]

export function PromptEditor({ prompt, onSave, onCancel }: PromptEditorProps) {
  const [name, setName] = useState(prompt?.name || "")
  const [type, setType] = useState(prompt?.type || "custom")
  const [promptText, setPromptText] = useState(prompt?.prompt || "")
  const [description, setDescription] = useState(prompt?.description || "")
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim() || !promptText.trim()) {
      setError("Name and prompt text are required")
      return
    }
    setIsSaving(true)
    setError(null)
    try {
      await onSave({
        name,
        type: type as any,
        prompt: promptText,
        description,
      })
    } catch (err) {
      setError("Failed to save prompt. Please try again.")
      console.error(err)
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="p-6 border border-border bg-white rounded-lg shadow-sm">
      <h3 className="mb-4 text-lg font-bold text-foreground">{prompt ? "✏️ Edit Prompt" : "✨ Create New Prompt"}</h3>

      {error && (
        <div className="mb-4 flex items-center gap-3 rounded-lg border border-red-200 bg-red-50 p-4">
          <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0" />
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-sm font-semibold text-foreground mb-2 block">Prompt Name</label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Email Categorization"
            className="border-border focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="text-sm font-semibold text-foreground mb-2 block">Type</label>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="w-full rounded-lg border border-border bg-white px-3 py-2 text-sm text-foreground focus:border-blue-500 focus:ring-blue-500"
          >
            {promptTypes.map((t) => (
              <option key={t} value={t}>
                {t.replace("_", " ").charAt(0).toUpperCase() + t.replace("_", " ").slice(1)}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-sm font-semibold text-foreground mb-2 block">Description (Optional)</label>
          <Input
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="What does this prompt do?"
            className="border-border focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="text-sm font-semibold text-foreground mb-2 block">Prompt Text</label>
          <Textarea
            value={promptText}
            onChange={(e) => setPromptText(e.target.value)}
            placeholder="Enter your prompt. Use {email_content} as a placeholder for email content."
            rows={6}
            className="border-border focus:border-blue-500 focus:ring-blue-500 font-mono"
          />
          <p className="mt-2 text-xs text-muted-foreground flex items-center gap-1">
            💡 Use {"{email_content}"} as a placeholder for the email content
          </p>
        </div>

        <div className="flex gap-2 pt-2">
          <Button type="submit" disabled={isSaving} className="bg-blue-600 hover:bg-blue-700 text-white font-semibold">
            {isSaving ? "Saving..." : "Save Prompt"}
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            className="border-border hover:bg-muted bg-transparent"
          >
            Cancel
          </Button>
        </div>
      </form>
    </div>
  )
}
