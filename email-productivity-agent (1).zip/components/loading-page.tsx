"use client"

export function LoadingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-blue-50/50 flex flex-col items-center justify-center">
      <div className="relative w-32 h-32 mb-8">
        {/* Outer rotating ring */}
        <div
          className="absolute inset-0 rounded-full border-4 border-transparent border-t-blue-500 border-r-purple-500 animate-spin"
          style={{ animationDuration: "3s" }}
        />

        {/* Middle rotating ring */}
        <div
          className="absolute inset-2 rounded-full border-4 border-transparent border-b-green-500 border-l-blue-400 animate-spin"
          style={{ animationDuration: "2s", animationDirection: "reverse" }}
        />

        {/* Inner logo */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center shadow-lg">
            <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
              />
            </svg>
          </div>
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-2xl font-bold text-foreground mb-2">Email Productivity Agent</h2>
        <p className="text-muted-foreground mb-1">Loading your inbox...</p>
        <p className="text-xs text-muted-foreground">Initializing with AI-powered features</p>
      </div>

      {/* Animated dots */}
      <div className="flex gap-2 mt-8">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="w-2 h-2 rounded-full bg-gradient-to-r from-blue-500 to-purple-500"
            style={{
              animation: "pulse 1.5s ease-in-out infinite",
              animationDelay: `${i * 0.2}s`,
            }}
          />
        ))}
      </div>
    </div>
  )
}
