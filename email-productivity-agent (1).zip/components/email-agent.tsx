"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import type { Email, Draft } from "@/lib/types"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Send, Loader2, AlertCircle, Download, FileText, Lightbulb } from "lucide-react"

interface EmailAgentProps {
  selectedEmailId: string | null
  emails: Email[]
}

interface ChatMessage {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  type?: "text" | "summary" | "draft" | "analysis"
}

const demoResponses: Record<string, (email?: Email) => string> = {
  summarize: (email?: Email) => `📋 **Summary of Email**

The email from ${email?.from || "John"} discusses ${email?.subject || "an important matter"}.

**Key Points:**
• Topic 1: Discusses the main agenda and objectives
• Topic 2: Provides important updates on project progress
• Topic 3: Requests feedback and action items

**Overall Tone:** Professional and informative
**Priority:** High - Requires response

This email covers important business matters that need prompt attention.`,

  reply: (email?: Email) => `✉️ **Suggested Reply Draft**

Dear ${email?.from?.split("@")[0] || "Sender"},

Thank you for your email regarding ${email?.subject || "the mentioned topic"}.

I appreciate the comprehensive information you've provided. I will review the details and get back to you with my feedback by end of week.

Best regards,
Your Name`,

  actions: (email?: Email) => `✓ **Action Items Extracted**

From: ${email?.from || "Sender"}
Subject: ${email?.subject || "Email"}

**Tasks to Complete:**
1. Review the attached documents and provide feedback
   - Deadline: This week
   - Priority: High

2. Schedule a meeting to discuss further
   - Suggested date: Next Monday
   - Duration: 30-45 minutes

3. Send confirmation of receipt
   - Deadline: Within 24 hours
   - Status: Not started

**Total Items:** 3 | **Urgent:** 2 | **Routine:** 1`,

  tone: (email?: Email) => `🎭 **Tone Analysis**

**Overall Tone:** Professional
- Formality Level: Formal (Business)
- Sentiment: Positive/Neutral
- Urgency: High

**Characteristics:**
✓ Respectful language
✓ Clear communication
✓ Action-oriented
✓ Professional structure

**Suggested Response Tone:** Match the professional, formal tone with clear action items.`,

  spam: (email?: Email) => `🔍 **Email Classification Analysis**

**Classification:** Legitimate - Important

**Confidence Score:** 98%

**Analysis:**
✓ Legitimate sender domain
✓ Professional email structure
✓ Clear business intent
✓ Personalized content
✓ No suspicious links

**Recommendation:** This is a legitimate business email. Archive for reference.`,
}

const suggestedPrompts = [
  "Summarize this email",
  "Draft a reply",
  "What are the action items?",
  "Analyze the tone",
  "Is this spam or important?",
]

export function EmailAgent({ selectedEmailId, emails }: EmailAgentProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [drafts, setDrafts] = useState<Draft[]>([])
  const [error, setError] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const selectedEmail = emails.find((e) => e.id === selectedEmailId)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  useEffect(() => {
    const loadDrafts = async () => {
      try {
        setError(null)
        const response = await fetch("/api/drafts")
        if (!response.ok) throw new Error("Failed to fetch drafts")
        setDrafts(await response.json())
      } catch (err) {
        console.error("Error loading drafts:", err)
        setError("Failed to load drafts")
      }
    }
    loadDrafts()
  }, [])

  const getResponseForQuery = (query: string, email?: Email): string => {
    const lowerQuery = query.toLowerCase()

    if (lowerQuery.includes("summarize")) return demoResponses.summarize(email)
    if (lowerQuery.includes("reply") || lowerQuery.includes("respond")) return demoResponses.reply(email)
    if (lowerQuery.includes("action") || lowerQuery.includes("tasks") || lowerQuery.includes("todo"))
      return demoResponses.actions(email)
    if (lowerQuery.includes("tone") || lowerQuery.includes("sentiment")) return demoResponses.tone(email)
    if (lowerQuery.includes("spam") || lowerQuery.includes("classify") || lowerQuery.includes("legitimate"))
      return demoResponses.spam(email)

    // Default response
    return `I can help you with various email operations:
    
• **Summarize** - Get a concise summary of the email
• **Draft a Reply** - Generate a professional response
• **Action Items** - Extract tasks and deadlines
• **Analyze Tone** - Understand the email's tone and sentiment
• **Spam Check** - Verify if the email is legitimate

Try asking me to do any of these with the selected email!`
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)
    setError(null)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const responseContent = getResponseForQuery(input, selectedEmail)

      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: responseContent,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (err) {
      console.error("Error sending message:", err)
      setError("Failed to send message. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleSaveDraft = async (content: string) => {
    try {
      setError(null)
      const response = await fetch("/api/drafts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject: selectedEmail?.subject ? `RE: ${selectedEmail.subject}` : "New Email",
          body: content,
          emailId: selectedEmailId,
          tone: "professional",
        }),
      })
      if (!response.ok) throw new Error("Failed to save draft")
      const newDraft = await response.json()
      setDrafts((prev) => [...prev, newDraft])
      alert("Draft saved successfully!")
    } catch (err) {
      console.error("Error saving draft:", err)
      setError("Failed to save draft")
    }
  }

  const handleSuggestedPrompt = (prompt: string) => {
    setInput(prompt)
  }

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="lg:col-span-2 space-y-4">
        {error && (
          <div className="flex items-center gap-3 rounded-lg border border-red-200 bg-red-50 p-4">
            <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        <div className="flex h-96 flex-col border border-border bg-white rounded-xl shadow-md overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-white to-emerald-50/20">
            {messages.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center text-center p-4">
                <div className="mb-4 inline-block p-4 rounded-full bg-gradient-to-br from-emerald-100 to-green-100 border border-emerald-200">
                  <Lightbulb className="h-8 w-8 text-emerald-600" />
                </div>
                <p className="font-bold text-foreground text-lg">Email Assistant Ready</p>
                <p className="text-sm text-muted-foreground mt-2 max-w-xs">
                  {selectedEmail
                    ? "Ask me anything about this email and I'll provide instant insights"
                    : "Select an email to get started"}
                </p>

                {selectedEmail && (
                  <div className="mt-6 space-y-3 w-full">
                    <p className="text-xs text-muted-foreground font-semibold uppercase">Popular commands:</p>
                    <div className="flex flex-wrap gap-2 justify-center">
                      {suggestedPrompts.map((prompt) => (
                        <button
                          key={prompt}
                          onClick={() => handleSuggestedPrompt(prompt)}
                          className="px-3 py-1.5 text-xs rounded-full bg-gradient-to-r from-emerald-100 to-green-100 text-emerald-700 hover:from-emerald-200 hover:to-green-200 transition-colors border border-emerald-300 font-medium shadow-sm hover:shadow"
                        >
                          {prompt}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-xs rounded-lg px-4 py-3 text-sm whitespace-pre-wrap ${
                      msg.role === "user"
                        ? "bg-gradient-to-r from-emerald-600 to-green-600 text-white rounded-br-none shadow-md"
                        : "bg-gray-100 text-foreground rounded-bl-none border border-border shadow-sm"
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex justify-start">
                <div className="rounded-lg bg-gray-100 border border-border px-4 py-3 flex items-center gap-2 shadow-sm">
                  <Loader2 className="h-4 w-4 animate-spin text-emerald-600" />
                  <span className="text-xs text-muted-foreground">Processing...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={handleSendMessage} className="border-t border-border p-4 bg-white">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={selectedEmail ? "Ask about this email..." : "Select an email first..."}
                disabled={isLoading || !selectedEmail}
                className="border-border focus:border-emerald-500 focus:ring-emerald-500 bg-white"
              />
              <Button
                type="submit"
                disabled={isLoading || !input.trim() || !selectedEmail}
                className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white disabled:opacity-50"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </form>
        </div>

        {selectedEmail && (
          <div className="p-4 border border-emerald-200 bg-gradient-to-br from-emerald-50 to-green-50 rounded-xl shadow-sm">
            <h3 className="font-semibold mb-3 text-emerald-900">📧 Current Email</h3>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                <span className="text-muted-foreground font-medium">From:</span>{" "}
                <span className="font-medium text-foreground">{selectedEmail.from}</span>
              </p>
              <p className="text-sm text-muted-foreground">
                <span className="text-muted-foreground font-medium">Subject:</span>{" "}
                <span className="font-medium text-foreground line-clamp-2">{selectedEmail.subject}</span>
              </p>
            </div>
          </div>
        )}
      </div>

      <div className="lg:col-span-1">
        <div className="border border-emerald-200 bg-gradient-to-b from-white to-emerald-50 p-4 h-full rounded-xl shadow-md">
          <h3 className="font-bold mb-4 text-foreground text-lg flex items-center gap-2">
            <Download className="h-5 w-5 text-emerald-600" />
            Saved Drafts
          </h3>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {drafts.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-foreground font-medium">No drafts yet</p>
                <p className="text-xs text-muted-foreground mt-1">Create one from chat responses</p>
              </div>
            ) : (
              drafts.map((draft) => (
                <div
                  key={draft.id}
                  className="rounded-lg bg-gradient-to-br from-emerald-50 to-green-50 p-3 text-sm border border-emerald-200 hover:border-emerald-300 transition-all shadow-sm"
                >
                  <p className="font-semibold truncate text-emerald-700 text-xs">{draft.subject}</p>
                  <p className="text-xs text-muted-foreground mt-2 line-clamp-3">{draft.body}</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2 h-7 text-xs w-full bg-emerald-100 hover:bg-emerald-200 text-emerald-700 font-semibold"
                    onClick={() => handleSaveDraft(draft.body)}
                  >
                    Use Template
                  </Button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
