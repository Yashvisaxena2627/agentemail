"use client"

import type React from "react"

import { useState } from "react"
import type { Email } from "@/lib/types"
import { Badge } from "./ui/badge"
import { Button } from "./ui/button"
import { format } from "date-fns"
import { Check, Copy, AlertCircle, CheckCircle2, Clock, Mail, Send, ArrowRight } from "lucide-react"

interface EmailDetailProps {
  email: Email
  onEmailUpdate: (email: Email) => void
}

export function EmailDetail({ email, onEmailUpdate }: EmailDetailProps) {
  const [isProcessing, setIsProcessing] = useState(false)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const isSentEmail = (email as any).type === "sent" || email.category === "sent"

  const handleMarkAsRead = async () => {
    try {
      setError(null)
      const response = await fetch("/api/emails", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: email.id,
          updates: { isRead: !email.isRead },
        }),
      })
      if (!response.ok) throw new Error("Failed to update email")
      const updated = await response.json()
      onEmailUpdate(updated)
    } catch (err) {
      console.error("Error updating email:", err)
      setError("Failed to update email")
    }
  }

  const handleCopyContent = () => {
    navigator.clipboard.writeText(email.body)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const categoryConfig: Record<string, { icon: React.ReactNode; color: string; bg: string }> = {
    Important: {
      icon: <AlertCircle className="h-5 w-5" />,
      color: "bg-red-100 text-red-700 border-red-200",
      bg: "bg-red-50",
    },
    "To-Do": {
      icon: <CheckCircle2 className="h-5 w-5" />,
      color: "bg-blue-100 text-blue-700 border-blue-200",
      bg: "bg-blue-50",
    },
    Newsletter: {
      icon: <Mail className="h-5 w-5" />,
      color: "bg-purple-100 text-purple-700 border-purple-200",
      bg: "bg-purple-50",
    },
    sent: {
      icon: <Send className="h-5 w-5" />,
      color: "bg-green-100 text-green-700 border-green-200",
      bg: "bg-green-50",
    },
  }

  const config = email.category ? categoryConfig[email.category] : isSentEmail ? categoryConfig.sent : null

  return (
    <div className="rounded-lg border border-border bg-white shadow-sm">
      {error && (
        <div className="mb-4 flex items-center gap-3 rounded-lg border border-red-200 bg-red-50 p-4 m-6 mb-0">
          <AlertCircle className="h-5 w-5 text-red-600" />
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      <div className="border-b border-border p-6">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-foreground leading-snug">{email.subject}</h1>
            <div className="mt-3 space-y-1.5">
              {isSentEmail ? (
                <>
                  <p className="text-sm text-muted-foreground">
                    <span className="text-muted-foreground font-medium">From:</span>{" "}
                    <span className="font-medium text-foreground">You</span>
                  </p>
                  <p className="text-sm text-muted-foreground flex items-center gap-2">
                    <ArrowRight className="h-3.5 w-3.5 text-green-600" />
                    <span className="text-muted-foreground font-medium">To:</span>{" "}
                    <span className="font-medium text-foreground">{email.to}</span>
                  </p>
                </>
              ) : (
                <>
                  <p className="text-sm text-muted-foreground">
                    <span className="text-muted-foreground font-medium">From:</span>{" "}
                    <span className="font-medium text-foreground">{email.from}</span>
                  </p>
                  <p className="text-sm text-muted-foreground">
                    <span className="text-muted-foreground font-medium">To:</span>{" "}
                    <span className="font-medium text-foreground">{email.to}</span>
                  </p>
                </>
              )}
            </div>
          </div>
          {!isSentEmail && (
            <Button
              onClick={handleMarkAsRead}
              variant={email.isRead ? "outline" : "default"}
              size="sm"
              className={email.isRead ? "border-border hover:bg-muted" : "bg-blue-600 hover:bg-blue-700 text-white"}
            >
              {email.isRead ? "Mark Unread" : "Mark Read"}
            </Button>
          )}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-border">
          <span className="text-xs text-muted-foreground font-medium">
            {isSentEmail ? "Sent" : "Received"}: {format(new Date(email.timestamp), "PPpp")}
          </span>
          {config && (
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full ${config.bg}`}>
              <div className="text-base">{config.icon}</div>
              <span className={`text-xs font-semibold ${config.color.split(" ")[1]}`}>
                {isSentEmail ? "Sent" : email.category}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Body */}
      <div className="p-6 border-b border-border">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-semibold text-foreground">Email Content</h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleCopyContent}
            className="text-muted-foreground hover:text-foreground hover:bg-muted"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="h-4 w-4 mr-1" />
                Copy
              </>
            )}
          </Button>
        </div>
        <div className="rounded-lg bg-muted p-4 text-sm text-foreground whitespace-pre-wrap border border-border font-mono">
          {email.body}
        </div>
      </div>

      {/* Action Items */}
      {email.actionItems && email.actionItems.length > 0 && !isSentEmail && (
        <div className="border-t border-border p-6">
          <h3 className="mb-4 font-semibold text-foreground text-lg">Action Items</h3>
          <ul className="space-y-3">
            {email.actionItems.map((item) => (
              <li key={item.id} className="flex items-start gap-4 rounded-lg bg-blue-50 p-4 border border-blue-200">
                <input type="checkbox" className="mt-1 cursor-pointer accent-blue-600" />
                <div className="flex-1">
                  <p className="font-semibold text-foreground text-sm">{item.task}</p>
                  {item.deadline && (
                    <div className="flex items-center gap-2 mt-2">
                      <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                      <p className="text-xs text-muted-foreground">
                        Due: {format(new Date(item.deadline), "MMM d, yyyy")}
                      </p>
                    </div>
                  )}
                </div>
                {item.priority && (
                  <Badge
                    className={`text-xs font-semibold flex-shrink-0 ${
                      item.priority === "high"
                        ? "bg-red-100 text-red-700 border-red-200"
                        : item.priority === "medium"
                          ? "bg-yellow-100 text-yellow-700 border-yellow-200"
                          : "bg-green-100 text-green-700 border-green-200"
                    }`}
                  >
                    {item.priority}
                  </Badge>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
