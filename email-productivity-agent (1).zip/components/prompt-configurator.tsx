"use client"

import { useState, useEffect } from "react"
import type { PromptConfig } from "@/lib/types"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { PromptEditor } from "./prompt-editor"
import { Plus, Edit2, Trash2, AlertCircle } from "lucide-react"

export function PromptConfigurator() {
  const [prompts, setPrompts] = useState<PromptConfig[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [showNew, setShowNew] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadPrompts = async () => {
      try {
        setError(null)
        const response = await fetch("/api/prompts")
        if (!response.ok) throw new Error("Failed to fetch prompts")
        const data = await response.json()
        setPrompts(data)
      } catch (err) {
        console.error("Error loading prompts:", err)
        setError("Failed to load prompts")
      } finally {
        setIsLoading(false)
      }
    }

    loadPrompts()
  }, [])

  const handleSavePrompt = async (prompt: Partial<PromptConfig>) => {
    try {
      setError(null)
      if (editingId) {
        const response = await fetch("/api/prompts", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            id: editingId,
            updates: prompt,
          }),
        })
        if (!response.ok) throw new Error("Failed to update prompt")
        const updated = await response.json()
        setPrompts(prompts.map((p) => (p.id === editingId ? updated : p)))
      } else {
        const response = await fetch("/api/prompts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(prompt),
        })
        if (!response.ok) throw new Error("Failed to create prompt")
        const newPrompt = await response.json()
        setPrompts([...prompts, newPrompt])
      }
      setEditingId(null)
      setShowNew(false)
    } catch (err) {
      console.error("Error saving prompt:", err)
      setError("Failed to save prompt. Please try again.")
    }
  }

  const handleDeletePrompt = (id: string) => {
    if (confirm("Delete this prompt?")) {
      setPrompts(prompts.filter((p) => p.id !== id))
    }
  }

  if (isLoading) {
    return <div className="text-center text-muted-foreground py-12">Loading prompts...</div>
  }

  const typeColors: Record<string, { bg: string; text: string; icon: string }> = {
    categorization: { bg: "bg-blue-50", text: "text-blue-700", icon: "📂" },
    action_extraction: { bg: "bg-purple-50", text: "text-purple-700", icon: "✅" },
    auto_reply: { bg: "bg-green-50", text: "text-green-700", icon: "💬" },
    custom: { bg: "bg-orange-50", text: "text-orange-700", icon: "⚙️" },
  }

  return (
    <div className="space-y-6">
      {error && (
        <div className="flex items-center gap-3 rounded-lg border border-red-200 bg-red-50 p-4">
          <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0" />
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-foreground">Prompt Templates</h2>
          <p className="text-sm text-muted-foreground mt-1">Configure AI behavior with custom prompts</p>
        </div>
        <Button onClick={() => setShowNew(true)} className="bg-blue-600 hover:bg-blue-700 text-white shadow-md">
          <Plus className="h-4 w-4 mr-2" />
          New Prompt
        </Button>
      </div>

      {showNew && <PromptEditor onSave={handleSavePrompt} onCancel={() => setShowNew(false)} />}

      <div className="grid gap-4 md:grid-cols-2">
        {prompts.map((prompt) => {
          const colors = typeColors[prompt.type] || typeColors.custom
          return (
            <div
              key={prompt.id}
              className={`rounded-lg border border-border ${colors.bg} p-5 hover:shadow-md transition-all duration-300 ease-out`}
            >
              <div className="mb-4 flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{colors.icon}</span>
                    <div>
                      <h3 className="font-bold text-foreground text-lg">{prompt.name}</h3>
                      {prompt.description && (
                        <p className="text-xs text-muted-foreground mt-0.5">{prompt.description}</p>
                      )}
                    </div>
                  </div>
                </div>
                <Badge
                  variant={prompt.isDefault ? "default" : "secondary"}
                  className={`${colors.text} border flex-shrink-0`}
                >
                  {prompt.type.replace("_", " ")}
                </Badge>
              </div>

              <div className="mb-4 max-h-24 overflow-y-auto rounded-lg bg-white p-3 border border-border">
                <p className="text-xs text-foreground font-mono">{prompt.prompt}</p>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditingId(prompt.id)}
                  className="border-border hover:bg-muted"
                >
                  <Edit2 className="h-4 w-4" />
                </Button>
                {!prompt.isDefault && (
                  <Button variant="destructive" size="sm" onClick={() => handleDeletePrompt(prompt.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {editingId && (
        <PromptEditor
          prompt={prompts.find((p) => p.id === editingId)}
          onSave={handleSavePrompt}
          onCancel={() => setEditingId(null)}
        />
      )}
    </div>
  )
}
