"use client"

import { useState } from "react"
import type { Email } from "@/lib/types"
import { EmailList } from "./email-list"
import { EmailDetail } from "./email-detail"
import { Button } from "./ui/button"
import { RefreshCw } from "lucide-react"

interface InboxProps {
  emails: Email[]
  onEmailSelect: (emailId: string) => void
  selectedEmailId: string | null
  onEmailsUpdate: (emails: Email[]) => void
}

export function Inbox({ emails, onEmailSelect, selectedEmailId, onEmailsUpdate }: InboxProps) {
  const [isRefreshing, setIsRefreshing] = useState(false)

  const handleRefresh = async () => {
    setIsRefreshing(true)
    try {
      const response = await fetch("/api/emails")
      const data = await response.json()
      onEmailsUpdate(data)
    } catch (error) {
      console.error("Error refreshing emails:", error)
    } finally {
      setIsRefreshing(false)
    }
  }

  const selectedEmail = emails.find((e) => e.id === selectedEmailId)

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      {/* Email List */}
      <div className="lg:col-span-1">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-foreground">Emails</h2>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="border-border hover:bg-muted bg-transparent"
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
          </Button>
        </div>
        <div className="rounded-lg border border-border bg-white shadow-sm p-4">
          <EmailList emails={emails} selectedEmailId={selectedEmailId} onEmailSelect={onEmailSelect} />
        </div>
      </div>

      {/* Email Detail */}
      <div className="lg:col-span-2">
        {selectedEmail ? (
          <EmailDetail
            email={selectedEmail}
            onEmailUpdate={(updatedEmail) => {
              const updated = emails.map((e) => (e.id === updatedEmail.id ? updatedEmail : e))
              onEmailsUpdate(updated)
            }}
          />
        ) : (
          <div className="flex h-96 items-center justify-center rounded-lg border border-border bg-white shadow-sm">
            <p className="text-center text-muted-foreground">Select an email to view details</p>
          </div>
        )}
      </div>
    </div>
  )
}
