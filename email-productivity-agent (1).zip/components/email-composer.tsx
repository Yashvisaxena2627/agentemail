"use client"

import { useState } from "react"
import type React from "react"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { X, Send, AlertCircle, CheckCircle } from "lucide-react"

interface EmailComposerProps {
  isOpen: boolean
  onClose: () => void
  onEmailSent?: (email: any) => void
}

export function EmailComposer({ isOpen, onClose, onEmailSent }: EmailComposerProps) {
  const [recipientEmail, setRecipientEmail] = useState("")
  const [subject, setSubject] = useState("")
  const [body, setBody] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const handleSendEmail = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSuccess(false)

    if (!recipientEmail || !subject || !body) {
      setError("Please fill in all fields: recipient email, subject, and message")
      return
    }

    if (!recipientEmail.includes("@")) {
      setError("Please enter a valid email address")
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/send-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipientEmail,
          subject,
          body,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to send email")
      }

      const data = await response.json()
      setSuccess(true)

      setTimeout(() => {
        setRecipientEmail("")
        setSubject("")
        setBody("")
        if (onEmailSent) {
          onEmailSent(data.email)
        }
        onClose()
      }, 1500)
    } catch (err) {
      console.error("Error sending email:", err)
      setError(err instanceof Error ? err.message : "Failed to send email")
    } finally {
      setIsLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-sm">
      <div className="w-full max-w-2xl rounded-xl border border-border bg-white shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-6 py-4">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Compose Email</h2>
            <p className="text-xs text-muted-foreground mt-1">
              Send an email to yashivsaxena@gmail.com or any recipient
            </p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-muted rounded-lg transition-all duration-300 ease-out">
            <X className="h-5 w-5 text-muted-foreground" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSendEmail} className="p-6 space-y-4">
          {error && (
            <div className="flex items-start gap-3 rounded-lg border border-red-200 bg-red-50 p-4">
              <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          {success && (
            <div className="flex items-start gap-3 rounded-lg border border-green-200 bg-green-50 p-4">
              <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-green-700">Email sent successfully!</p>
                <p className="text-xs text-green-600 mt-1">Your email has been added to the inbox.</p>
              </div>
            </div>
          )}

          {/* Recipient Email */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">To</label>
            <Input
              type="email"
              value={recipientEmail}
              onChange={(e) => setRecipientEmail(e.target.value)}
              placeholder="recipient@example.com"
              disabled={isLoading || success}
              className="border-border focus:border-blue-500 focus:ring-blue-500 bg-white"
            />
            <p className="text-xs text-muted-foreground mt-1">Default: yashivsaxena@gmail.com</p>
          </div>

          {/* Subject */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">Subject</label>
            <Input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Email subject..."
              disabled={isLoading || success}
              className="border-border focus:border-blue-500 focus:ring-blue-500 bg-white"
            />
          </div>

          {/* Body */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">Message</label>
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Write your email message here..."
              disabled={isLoading || success}
              rows={8}
              className="w-full rounded-lg border border-border bg-white px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 disabled:opacity-50 transition-all duration-300 ease-out"
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="bg-muted hover:bg-muted/80 text-foreground"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading || success}
              className="bg-blue-600 hover:bg-blue-700 text-white shadow-md disabled:opacity-50"
            >
              <Send className="h-4 w-4 mr-2" />
              {isLoading ? "Sending..." : "Send Email"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
