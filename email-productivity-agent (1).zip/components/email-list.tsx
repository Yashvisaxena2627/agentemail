"use client"

import type React from "react"

import type { Email } from "@/lib/types"
import { Badge } from "./ui/badge"
import { format } from "date-fns"
import { Mail, AlertCircle, CheckCircle2, Zap, Send, ArrowRight } from "lucide-react"

interface EmailListProps {
  emails: Email[]
  selectedEmailId: string | null
  onEmailSelect: (emailId: string) => void
}

const categoryConfig: Record<string, { icon: React.ReactNode; color: string; bg: string; textColor: string }> = {
  Important: {
    icon: <AlertCircle className="h-4 w-4" />,
    color: "bg-red-100 text-red-700 border-red-200",
    bg: "bg-red-50",
    textColor: "text-red-600",
  },
  "To-Do": {
    icon: <CheckCircle2 className="h-4 w-4" />,
    color: "bg-blue-100 text-blue-700 border-blue-200",
    bg: "bg-blue-50",
    textColor: "text-blue-600",
  },
  Newsletter: {
    icon: <Mail className="h-4 w-4" />,
    color: "bg-purple-100 text-purple-700 border-purple-200",
    bg: "bg-purple-50",
    textColor: "text-purple-600",
  },
  Spam: {
    icon: <Zap className="h-4 w-4" />,
    color: "bg-gray-100 text-gray-700 border-gray-200",
    bg: "bg-gray-50",
    textColor: "text-gray-600",
  },
  sent: {
    icon: <Send className="h-4 w-4" />,
    color: "bg-green-100 text-green-700 border-green-200",
    bg: "bg-green-50",
    textColor: "text-green-600",
  },
}

export function EmailList({ emails, selectedEmailId, onEmailSelect }: EmailListProps) {
  const sentEmails = emails.filter((e) => e.category === "sent" || (e as any).type === "sent")
  const receivedEmails = emails.filter((e) => e.category !== "sent" && (e as any).type !== "sent")

  const renderEmailGroup = (groupEmails: Email[], title: string) => {
    if (groupEmails.length === 0) return null

    return (
      <div key={title} className="space-y-2">
        <h3 className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">{title}</h3>
        {groupEmails.map((email) => {
          const config = email.category ? categoryConfig[email.category] : categoryConfig.sent
          const isSentEmail = (email as any).type === "sent" || email.category === "sent"

          return (
            <button
              key={email.id}
              onClick={() => onEmailSelect(email.id)}
              className={`w-full text-left rounded-lg border-2 p-3 transition-all duration-300 ease-out ${
                selectedEmailId === email.id
                  ? `${config.bg} border-blue-500 shadow-md`
                  : "border-transparent hover:bg-gray-50 hover:border-border"
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    {isSentEmail && <ArrowRight className={`h-3.5 w-3.5 flex-shrink-0 ${config.textColor}`} />}
                    <h3 className="font-semibold text-sm truncate text-foreground">
                      {isSentEmail ? `To: ${email.to.split("@")[0]}` : email.from.split("@")[0]}
                    </h3>
                    {!email.isRead && !isSentEmail && (
                      <div className="h-2.5 w-2.5 rounded-full bg-blue-500 flex-shrink-0" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground truncate mt-1">{email.subject}</p>
                </div>
              </div>
              {email.category && (
                <div className="mt-2 flex items-center justify-between gap-2">
                  <Badge className={config.color}>{isSentEmail ? "Sent" : email.category}</Badge>
                  <span className="text-xs text-muted-foreground">{format(new Date(email.timestamp), "MMM d")}</span>
                </div>
              )}
            </button>
          )
        })}
      </div>
    )
  }

  return (
    <div className="space-y-4 max-h-[600px] overflow-y-auto">
      {renderEmailGroup(receivedEmails, "Inbox")}
      {renderEmailGroup(sentEmails, "Sent")}

      {emails.length === 0 && (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <Mail className="h-10 w-10 text-muted-foreground mb-3" />
          <p className="text-sm text-foreground font-medium">No emails yet</p>
          <p className="text-xs text-muted-foreground mt-1">Your inbox is empty</p>
        </div>
      )}
    </div>
  )
}
