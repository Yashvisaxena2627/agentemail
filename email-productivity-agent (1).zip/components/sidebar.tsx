"use client"

import React from "react"

import { useState } from "react"
import { useTheme } from "next-themes"
import { Mail, Send, Star, FileText, Settings, MessageSquare, Moon, Sun } from "lucide-react"
import { Button } from "./ui/button"

interface SidebarProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  React.useEffect(() => {
    setMounted(true)
  }, [])

  const sidebarItems = [
    { id: "inbox", icon: Mail, label: "Inbox", count: 8 },
    { id: "sent", icon: Send, label: "Sent", count: 2 },
    { id: "starred", icon: Star, label: "Starred", count: 3 },
    { id: "drafts", icon: FileText, label: "Drafts", count: 1 },
  ]

  const bottomItems = [
    { id: "prompts", icon: Settings, label: "Prompts" },
    { id: "agent", icon: MessageSquare, label: "Agent Chat" },
  ]

  const renderItem = (item: any) => (
    <button
      key={item.id}
      onClick={() => onTabChange(item.id)}
      className={`w-full flex items-center justify-between px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
        activeTab === item.id
          ? "bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-100 shadow-sm"
          : "text-foreground hover:bg-muted dark:hover:bg-muted"
      }`}
    >
      <div className="flex items-center gap-3">
        <item.icon className="h-4 w-4" />
        {item.label}
      </div>
      {item.count && (
        <span className="text-xs font-semibold bg-emerald-500 dark:bg-emerald-600 text-white rounded-full px-2 py-0.5">
          {item.count}
        </span>
      )}
    </button>
  )

  return (
    <aside className="w-64 border-r border-border bg-card dark:bg-card/50 h-screen sticky top-0 overflow-y-auto flex flex-col p-4">
      {/* Top section */}
      <div className="space-y-2 flex-1">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide px-4 mb-3">Mail</h3>
        <div className="space-y-1">{sidebarItems.map(renderItem)}</div>

        <div className="pt-4 mt-4 border-t border-border">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide px-4 mb-3">Tools</h3>
          <div className="space-y-1">{bottomItems.map(renderItem)}</div>
        </div>
      </div>

      {/* Bottom theme toggle */}
      <div className="pt-4 border-t border-border">
        {mounted && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="w-full justify-center gap-2"
          >
            {theme === "dark" ? (
              <>
                <Sun className="h-4 w-4" />
                Light Mode
              </>
            ) : (
              <>
                <Moon className="h-4 w-4" />
                Dark Mode
              </>
            )}
          </Button>
        )}
      </div>
    </aside>
  )
}
