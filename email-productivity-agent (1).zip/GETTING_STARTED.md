# Email Productivity Agent - Getting Started

Welcome! This guide will get you up and running in 5 minutes.

## What Is This?

An intelligent email management system powered by AI that:
- 📧 Automatically organizes your inbox
- 🤖 Lets you customize how AI behaves
- 💬 Includes an AI chat for your emails
- 📝 Generates draft replies safely
- ⚙️ Requires just 3 commands to start

## Quick Start (5 Minutes)

### Step 1: Get OpenAI API Key (2 minutes)
1. Go to https://platform.openai.com/api-keys
2. Sign up/login
3. Create a new API key
4. Copy it somewhere safe (you'll need it once)

### Step 2: Install (2 minutes)
\`\`\`bash
# Clone this project
git clone <project-url>
cd email-agent

# Install dependencies
npm install

# Create .env.local file
echo "OPENAI_API_KEY=sk_YOUR_KEY_HERE" > .env.local
# Replace YOUR_KEY_HERE with your actual key from Step 1
\`\`\`

### Step 3: Run (1 minute)
\`\`\`bash
npm run dev
\`\`\`

Open http://localhost:3000 in your browser.

**That's it!** The app will load with 10 sample emails.

## First Time Users: Try This

### 1️⃣ View Your Inbox (1 min)
- Click on the **Inbox** tab
- Click on any email to see details
- Notice the automatic **Category** tag (Important, To-Do, etc.)
- See the **Action Items** extracted with deadlines

### 2️⃣ Explore Prompts (1 min)
- Click on the **Prompts** tab
- See 4 default prompts
- Click "New Prompt" and create your first one:
  - Name: "Quick Summary"
  - Prompt: "Summarize this in one sentence: {email_content}"
- Click "Save Prompt"

### 3️⃣ Chat with AI (2 min)
- Click on the **Agent Chat** tab
- Select an email
- Ask the AI: "Summarize this email"
- Ask: "What tasks do I need to do?"
- Ask: "Draft a professional reply"
- See AI responses in real-time

### 4️⃣ Save Drafts (1 min)
- In the chat, generate a reply
- It automatically saves as a draft
- View saved drafts in the sidebar
- Drafts are never auto-sent (you decide)

## Troubleshooting

### Error: "OPENAI_API_KEY not found"
**Fix**: Check your `.env.local` file has the correct key

### Emails not loading?
**Fix**: Restart with `npm run dev` in a fresh terminal

### Chat not responding?
**Fix**: Verify your OpenAI key is valid at https://platform.openai.com/account/usage

### Port 3000 already in use?
**Fix**: Run on different port: `npm run dev -- -p 3001`

## Documentation Map

| Document | Read This For |
|----------|---------------|
| **README.md** | Complete feature overview |
| **SETUP_GUIDE.md** | Detailed setup instructions |
| **FEATURES.md** | Feature deep dive |
| **DEPLOYMENT.md** | Deploying to production |
| **DEMO_VIDEO_GUIDE.md** | Creating a demo video |
| **PROJECT_SUMMARY.md** | Technical overview |

## Next Steps

### Learn the System
- Read README.md for full features
- Try all three tabs thoroughly
- Create multiple custom prompts

### Customize It
- Adjust prompt templates for your work
- Try different LLM providers
- Modify the UI theme

### Deploy It
- Push to GitHub
- Deploy to Vercel (1 click)
- Set environment variables
- Share with others

### Extend It
- Add real email connection (Gmail API)
- Add user authentication
- Connect to a database
- Add email sending capability

## Key Features

### Inbox Management
- View all emails
- Automatic categorization (4 types)
- Extract action items with deadlines
- Mark read/unread
- Copy email content

### Prompt Configuration
- Create unlimited custom prompts
- 4 default prompts included
- Edit/delete prompts anytime
- Use {email_content} placeholder
- Different prompt types

### AI Email Agent
- Ask questions about emails
- Get summaries
- Draft replies
- Extract tasks
- General email assistance

### Safe Drafts
- All AI outputs saved as drafts
- Nothing sent automatically
- Review before use
- Use as templates

## Common Questions

**Q: Will emails be sent automatically?**  
A: No! Everything is saved as drafts. You review before taking action.

**Q: Can I use this with my real email account?**  
A: Currently it uses sample emails. Can be extended to connect Gmail/Outlook.

**Q: Is my data private?**  
A: Data stored locally on your computer. No cloud sync by default.

**Q: How much does it cost?**  
A: App is free. You pay for OpenAI API usage (~$0.0002 per email).

**Q: Can multiple people use this?**  
A: Currently single-user. Can add authentication for teams.

**Q: What if I want to deploy this?**  
A: See DEPLOYMENT.md for options (Vercel recommended).

## Tips & Tricks

1. **Better Categorization**: Create specific prompts for your work
2. **Faster Replies**: Create a "Quick Reply" prompt template
3. **Custom Workflows**: Make prompts for your industry/role
4. **Batch Processing**: Process multiple emails together
5. **Test Prompts**: Try variations to find what works best

## Technical Stack

- **Frontend**: React 19, Next.js 16
- **AI**: OpenAI via Vercel AI SDK
- **Storage**: Local JSON files
- **Styling**: Tailwind CSS + shadcn/ui
- **Language**: TypeScript

## Support

- **Setup issues**: Check SETUP_GUIDE.md
- **Feature questions**: Check FEATURES.md
- **Deployment**: Check DEPLOYMENT.md
- **Demo help**: Check DEMO_VIDEO_GUIDE.md
- **Error logs**: Check browser console (F12)

## What's Next?

Choose your path:

### Path 1: Learn & Explore
- [ ] Finish this guide
- [ ] Try all features
- [ ] Create custom prompts
- [ ] Read full README.md

### Path 2: Customize & Deploy
- [ ] Read DEPLOYMENT.md
- [ ] Deploy to Vercel
- [ ] Set up domain
- [ ] Share with users

### Path 3: Extend & Build
- [ ] Connect real email
- [ ] Add authentication
- [ ] Connect database
- [ ] Build custom features

### Path 4: Demo & Share
- [ ] Read DEMO_VIDEO_GUIDE.md
- [ ] Record demo video
- [ ] Share on social media
- [ ] Gather feedback

## Frequently Used Commands

\`\`\`bash
# Start development server
npm run dev

# Build for production
npm run build

# Run production build locally
npm start

# Check code style
npm run lint

# Reset database (if needed)
rm -rf data/
npm run dev
\`\`\`

## System Requirements

- Node.js 18 or higher
- npm or yarn
- ~500MB disk space
- Modern web browser
- Internet connection (for OpenAI API)

## Video Introduction

A video guide is available in DEMO_VIDEO_GUIDE.md showing:
- Dashboard overview
- Email inbox features
- Prompt configuration
- AI chat in action
- Draft generation

## Key Files

| File | Purpose |
|------|---------|
| `app/page.tsx` | Main dashboard |
| `app/api/chat/route.ts` | AI chat endpoint |
| `lib/storage.ts` | Data storage |
| `lib/mock-data.ts` | Sample emails |
| `.env.local` | Configuration |

## One More Thing

This system is designed for you to:
- Use immediately
- Customize freely
- Deploy easily
- Extend as needed

All code is well-commented, documented, and ready to modify.

---

**Ready?** Run these three commands:

\`\`\`bash
npm install
echo "OPENAI_API_KEY=sk_YOUR_KEY_HERE" > .env.local
npm run dev
\`\`\`

Then visit http://localhost:3000 and start exploring!

**Questions?** Check the other documentation files - answers are there.

**Happy email managing!** 🚀
