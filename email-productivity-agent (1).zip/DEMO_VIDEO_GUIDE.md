# Email Productivity Agent - Demo Video Guide

Create a compelling 5-10 minute demo showing all features.

## Demo Script (5-10 minutes)

### Intro (30 seconds)
\`\`\`
"Welcome to the Email Productivity Agent, an AI-powered system that 
intelligently manages your inbox. Today I'll show you three core features:
automatic email categorization, custom prompt configuration, and our 
AI-powered email chat interface."
\`\`\`

### Section 1: Dashboard Overview (1 minute)

**Show:**
- Landing page with three tabs
- Explain each tab's purpose:
  - Inbox: View and manage emails
  - Prompts: Configure AI behavior  
  - Agent Chat: Chat with AI about emails

**Script:**
"The dashboard has three main sections. The Inbox tab shows your emails 
with automatic categorization. The Prompts tab lets you configure how 
the AI behaves. And the Agent Chat tab is where you interact with the AI."

**Action:**
- Click between tabs
- Highlight the clean dark UI

---

### Section 2: Email Inbox (2 minutes)

**Show:**
1. Email list with categories visible
2. Click on an email to view details
3. Show action items extracted from emails
4. Show read/unread toggle

**Script:**
"Here's our email inbox with 10 sample emails. Notice how each email 
is automatically categorized as Important, To-Do, Newsletter, or Spam. 
Let me click on this important email from my manager."

**Actions:**
- Click an Important email (Q4 Project Kickoff)
- Show full email content
- Highlight the automatically extracted action item
- Show the deadline
- Click "Mark Read" to toggle status

**Talking Points:**
- "The email was automatically categorized as Important"
- "Action items are extracted with deadlines"
- "This task is marked as high priority"
- "You can mark emails as read to track what you've reviewed"

---

### Section 3: Prompts Configuration (2 minutes)

**Show:**
1. Go to Prompts tab
2. Show default prompts (scroll through them)
3. Create a new custom prompt
4. Show how prompts work

**Script:**
"Now let's look at the Prompts tab. This is where we configure how 
the AI processes emails. I have four default prompts pre-configured 
for categorization, action extraction, meeting replies, and summaries."

**Actions:**
- Go to Prompts tab
- Show each default prompt (click to expand)
- Click "New Prompt" button
- Fill in:
  - Name: "Urgency Detection"
  - Type: "Custom"
  - Description: "Detect if email is urgent"
  - Prompt: "Rate this email's urgency (1-10). Email: {email_content}"
- Click "Save Prompt"

**Talking Points:**
- "Default prompts are ready to use immediately"
- "You can customize prompts for your specific needs"
- "Use {email_content} to include the email text"
- "Each prompt type (categorization, extraction, etc.) has different use cases"
- "Your custom prompts are saved and available in the Agent Chat"

---

### Section 4: Email Agent Chat (2-3 minutes)

**Show:**
1. Go to Agent Chat tab
2. Select an email
3. Ask multiple questions
4. Show drafts sidebar
5. Generate and save a draft

**Script:**
"The Email Agent Chat is where the AI comes to life. Select an email 
and ask the AI anything about it. It understands context and can help 
with summarization, reply drafting, and more."

**Actions:**
1. Go to Agent Chat tab
2. Select the Q4 Project email
3. Ask first question: "Summarize this email"
   - Wait for response (show real-time)
4. Ask second question: "What are the action items?"
   - Show AI understanding
5. Ask third question: "Draft a professional reply"
   - Show full response
6. Create a draft from the conversation
7. Show it in the drafts sidebar

**Talking Points:**
- "The AI uses the email context to provide relevant responses"
- "You can ask follow-up questions to refine the response"
- "Drafts are saved but never sent - you review them first"
- "This conversation shows how the AI adapts to your workflow"

**Questions to Ask:**
\`\`\`
"Summarize this email"
"What action items are here?"
"Draft a professional reply"
"Is this meeting request urgent?"
\`\`\`

---

### Section 5: Advanced Features (1 minute)

**Show:**
- Automatic email processing
- Real-time categorization
- Custom prompt application

**Script:**
"Let me show you the system working end-to-end. When emails arrive, 
the system automatically categorizes them using your configured prompts. 
You can refine these prompts anytime to improve accuracy."

**Actions:**
- Go back to Inbox
- Show multiple emails with different categories
- Explain the processing pipeline

**Talking Points:**
- "All processing happens using your custom prompts"
- "You have full control over AI behavior"
- "Prompts can be updated anytime for better results"
- "All drafts and emails are safely stored"

---

### Outro (30 seconds)

\`\`\`
"That's the Email Productivity Agent. It combines intelligent 
categorization, customizable prompts, and an AI chat interface 
to help you manage email more effectively. All drafts are reviewed 
before sending - safety first. Try it yourself, and customize 
the prompts to match your workflow."
\`\`\`

---

## Demo Tips

### Do's ✓
- **Go slow** - Let features sink in
- **Explain the why** - Why each feature matters
- **Show real interactions** - Don't just read slides
- **Be natural** - Talk like you're teaching a friend
- **Pause for effect** - Give time to absorb info
- **Emphasize safety** - Highlight draft-first approach
- **Show customization** - Create a prompt live
- **Test interaction** - Use the chat feature

### Don'ts ✗
- Don't go too fast
- Don't skip over features
- Don't use technical jargon
- Don't read bullet points
- Don't use placeholder text
- Don't forget to explain prompts
- Don't send emails (demo only!)
- Don't show API keys/secrets

---

## Technical Setup for Recording

### Equipment
- Good microphone (AirPods Pro, etc.)
- Screen recording software (OBS, ScreenFlow, Camtasia)
- 1080p or 4K resolution
- 30+ FPS

### Software Recommendations
- **Mac**: ScreenFlow, OBS
- **Windows**: OBS, Camtasia
- **Online**: Loom, ScreencastO-Matic

### Recording Settings
- Resolution: 1920x1080 (or scale to fit)
- Frame Rate: 30 fps minimum
- Audio: High quality microphone
- Screen: Zoom to 125% for readability

### Pre-Recording Checklist
- [ ] Close all distracting apps
- [ ] Have data/emails ready
- [ ] Test microphone
- [ ] Clean desk/background
- [ ] Verify screen brightness
- [ ] Check internet connection
- [ ] Have script ready
- [ ] Test screen recording

---

## Post-Production Tips

### Editing
1. Remove long pauses (> 2 seconds)
2. Speed up data loading (1.5x speed)
3. Add text overlays for key points
4. Add cursor highlights to show interactions
5. Use B-roll if showing multiple features

### Audio
- Use consistent, clear microphone
- Add background music at low volume
- Use sound effects for transitions (subtle)
- Normalize audio levels

### Captions
- Add captions for accessibility
- Highlight important points
- Use clear, readable fonts
- Show command highlights when typing

### Thumbnails
- Use contrasting colors
- Include app logo/name
- Add text: "Email AI Agent Demo"
- Use a friendly expression

---

## Demo Scenarios

### Scenario 1: Professional Context
"I'm a project manager reviewing my inbox at the start of the day."
- Show filtering by category
- Highlight action items with deadlines
- Demo asking about meeting logistics

### Scenario 2: Customer Support
"I'm triaging customer support emails."
- Show categorization by urgency
- Extract action items per customer
- Generate templated responses

### Scenario 3: Marketing/Sales
"I'm managing inbound leads and inquiries."
- Categorize by lead quality
- Extract follow-up items
- Draft responses quickly

---

## Talking Points to Emphasize

1. **AI-Powered But User-Controlled**
   - "You define how the AI behaves"
   - "Custom prompts give you full control"

2. **Safety-First**
   - "Everything is a draft first"
   - "No auto-sending"
   - "You review before any action"

3. **Time Saving**
   - "Automate tedious categorization"
   - "Extract tasks instantly"
   - "Draft replies in seconds"

4. **Customizable**
   - "Create prompts for your workflow"
   - "Adjust categorization"
   - "Improve over time"

5. **Easy to Use**
   - "No technical knowledge needed"
   - "Intuitive interface"
   - "Works immediately"

---

## Scripted Dialogue Examples

### Introducing Inbox
\`\`\`
"Let me show you the inbox. You can see 10 sample emails that have 
been automatically categorized. Here's an important email from my 
manager about the Q4 project kickoff. The system extracted the main 
action item and identified the deadline for next week."
\`\`\`

### Explaining Prompts
\`\`\`
"The power of this system is in the prompts. These define exactly 
how the AI processes your emails. I can modify them, or create new 
ones for specific use cases. For example, if I'm in sales mode, I 
could create a prompt specifically for lead qualification."
\`\`\`

### Demonstrating Chat
\`\`\`
"Now let me ask the AI a question about this email. I'm asking it 
to summarize the content... and in seconds, I get a concise summary. 
I could also ask it to draft a reply, extract tasks, or anything else 
I need."
\`\`\`

---

## Video Length Guidelines

- **Quick Intro (5 min)**: 1 inbox, 1 prompt, 1 chat demo
- **Full Demo (10 min)**: All features with explanations
- **Tutorial (15+ min)**: Feature deep-dive with examples
- **Feature Spotlight (3 min)**: Focus on one feature

---

## Distribution

### Where to Share
- YouTube
- LinkedIn
- Twitter
- Product Hunt
- Your GitHub repo
- Company website

### Descriptions to Use
\`\`\`
"Email Productivity Agent - AI-powered inbox management with custom 
prompts. Automatically categorize emails, extract action items, and 
generate replies. Built with Next.js, React, and OpenAI.

Features:
- Automatic email categorization
- Action item extraction
- AI-powered draft generation
- Custom prompt configuration
- Safe draft-first approach

Try it: [link]
Repo: [link]
Docs: [link]
"
\`\`\`

---

**Ready to record? You've got this!** 🎬
