# Troubleshooting Guide

## Common Issues & Solutions

### Issue: "Internal s..." JSON Error
**Error Message:** "Failed to execute 'json' on 'Response': Unexpected token 'I'"

**Cause:** API is returning HTML error page instead of JSON

**Solutions:**
1. Check OpenAI API key in `.env.local`
2. Verify key format starts with `sk_`
3. Restart dev server: `npm run dev`
4. Clear browser cache (Ctrl+Shift+Delete)
5. Check browser console (F12) for detailed error

### Issue: Emails Won't Load
**Error:** "Error loading emails: Failed to fetch"

**Solutions:**
1. Verify internet connection
2. Check if dev server is running
3. Refresh page (Ctrl+R)
4. Hard refresh (Ctrl+Shift+R)
5. Check browser console for 404/500 errors
6. Try in incognito/private mode

### Issue: Chat Not Responding
**Error:** "Failed to process chat request"

**Causes & Solutions:**
1. **API Key Invalid**
   - Check `.env.local` has correct key
   - Verify key starts with `sk_`
   - Test key at https://platform.openai.com

2. **API Rate Limited**
   - Wait a few minutes
   - Check OpenAI account at https://platform.openai.com
   - Upgrade account if needed

3. **No Email Selected**
   - Go to Inbox tab
   - Click an email to select it
   - Return to Agent Chat

### Issue: Data Not Saving
**Problem:** Changes lost when page refreshes

**Causes & Solutions:**
1. **localStorage Disabled**
   - Check browser settings
   - Enable localStorage
   - Try different browser

2. **Storage Full**
   - Clear browser cache
   - Delete old drafts
   - Start fresh

3. **Browser Privacy Mode**
   - Doesn't support localStorage
   - Use normal browsing mode

### Issue: Prompts Won't Save
**Error:** "Failed to save prompt"

**Solutions:**
1. Check prompt name and text aren't empty
2. Verify `{email_content}` placeholder is correct
3. Try simpler prompt first
4. Check browser console for errors
5. Clear browser cache and retry

### Issue: Draft Generation Fails
**Error:** "Failed to save draft"

**Solutions:**
1. Ensure email is selected
2. Check draft subject isn't empty
3. Verify body text isn't empty
4. Try shorter draft content
5. Check browser storage isn't full

### Issue: UI Looks Broken
**Problem:** Colors wrong, layout misaligned

**Solutions:**
1. Clear CSS cache:
   \`\`\`bash
   # In terminal
   rm -rf .next
   npm run dev
   \`\`\`

2. Hard refresh browser: Ctrl+Shift+R

3. Clear browser cache: Ctrl+Shift+Delete

4. Try different browser

### Issue: Port Already in Use
**Error:** "Port 3000 already in use"

**Solutions:**
\`\`\`bash
# Use different port
npm run dev -- -p 3001

# Or kill existing process
# On Windows:
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# On Mac/Linux:
lsof -i :3000
kill -9 <PID>
\`\`\`

### Issue: Module Not Found
**Error:** "Cannot find module..."

**Solutions:**
\`\`\`bash
# Reinstall dependencies
rm -rf node_modules
npm install

# Clear Next.js cache
rm -rf .next
npm run dev
\`\`\`

### Issue: OpenAI API Errors

**Error: Invalid API key**
- Check key format: `sk_...`
- Verify no extra spaces
- Copy from OpenAI dashboard carefully

**Error: Insufficient credits**
- Check OpenAI account balance
- Go to https://platform.openai.com/account/billing
- Add payment method if needed

**Error: Rate limit exceeded**
- Wait 60 seconds
- Make fewer requests
- Upgrade OpenAI plan

**Error: Model not available**
- Use correct model: `gpt-4o-mini`
- Check for model availability
- Verify account tier has access

## Browser Issues

### Chrome
- Clear cache: Menu > Settings > Privacy > Clear
- Disable extensions: Menu > Extensions
- Try Incognito mode

### Firefox
- Clear cache: Menu > Options > Privacy
- Disable add-ons: Menu > Add-ons
- Try Private Window

### Safari
- Clear cache: Develop > Empty Caches
- Clear cookies: Preferences > Privacy
- Try Private Window

## Performance Issues

### Slow Loading
**Solutions:**
1. Reduce number of sample emails
2. Close unused tabs
3. Clear browser cache
4. Restart browser
5. Check internet connection

### High Memory Usage
**Solutions:**
1. Clear browser cache
2. Reduce drafts/emails
3. Restart browser
4. Close other tabs
5. Upgrade browser

## Network Issues

### Cannot Connect
**Causes:**
- Server not running
- Network blocked
- Port blocked by firewall
- VPN interfering

**Solutions:**
1. Verify dev server running: `npm run dev`
2. Check URL: http://localhost:3000
3. Try different port: `npm run dev -- -p 3001`
4. Disable VPN temporarily
5. Check firewall settings

## Data Issues

### Lost All Data
**Prevention:**
1. Export important data
2. Use cloud backup
3. Regular backups

**Recovery:**
- Data is cached in browser
- May be recoverable in browser storage
- Try recovery extensions for browser

### Duplicate Emails
**Solution:**
1. Go to Inbox
2. Identify duplicates
3. Manually delete if needed
4. Refresh page

### Corrupted Prompt
**Solution:**
1. Delete problematic prompt
2. Create new one
3. Test with simple prompt first

## Deployment Issues

### Vercel Deployment
**API Key Not Found:**
\`\`\`bash
# Add to Vercel environment variables
OPENAI_API_KEY=sk_...
\`\`\`

**Build Fails:**
- Check Node.js version (18+)
- Run `npm run build` locally first
- Check for TypeScript errors: `npm run build`

### Self-Hosted Issues
**Port Already Used:**
- Change port in .env
- Use reverse proxy (nginx)
- Run on different server

**Memory Issues:**
- Increase heap size
- Use process manager (PM2)
- Spread load across instances

## Getting More Help

1. **Check Console** - F12 > Console tab for errors
2. **Check Network** - F12 > Network tab for failed requests
3. **Read Logs** - Check terminal output
4. **Search Issues** - Look up error message online
5. **Review Code Comments** - Files have helpful comments

## Debug Mode

Enable detailed logging:

\`\`\`typescript
// Add to lib/storage.ts
const DEBUG = true

if (DEBUG) {
  console.log("[DEBUG] Storage operation:", operation)
}
\`\`\`

## Contact & Support

- Check README.md for features
- See SETUP_GUIDE.md for installation
- Review code comments for implementation details
- Check OpenAI docs: https://platform.openai.com/docs

---

**Still stuck?** Check the error message in browser console (F12 > Console) for more details.
