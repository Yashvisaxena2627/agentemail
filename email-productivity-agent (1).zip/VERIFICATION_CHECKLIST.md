# Email Productivity Agent - Verification Checklist

Use this checklist to verify everything works correctly.

## Pre-Flight Checks

### Environment Setup
- [ ] Node.js 18+ installed (`node --version` shows 18+)
- [ ] npm installed (`npm --version` works)
- [ ] OpenAI API key obtained
- [ ] `.env.local` file created in project root
- [ ] OPENAI_API_KEY set in `.env.local`

### Project Installation
- [ ] Project downloaded/cloned
- [ ] `npm install` completed without errors
- [ ] No error messages in console
- [ ] `node_modules/` directory created
- [ ] `package.json` dependencies resolved

## Startup Verification

### Development Server
- [ ] Run `npm run dev` without errors
- [ ] Console shows "ready - started server"
- [ ] Server runs on http://localhost:3000
- [ ] No warning messages in console
- [ ] Server stays running (no crashes)

### Browser Loading
- [ ] Page loads at http://localhost:3000
- [ ] No "Cannot GET /" error
- [ ] CSS loads (not just plain HTML)
- [ ] Page shows Email Agent header
- [ ] Three tabs visible: Inbox, Prompts, Agent Chat

## Feature Verification

### Inbox Tab
- [ ] Inbox tab is clickable
- [ ] Shows list of emails (should show ~10)
- [ ] Each email has:
  - [ ] Sender name
  - [ ] Subject line
  - [ ] Unread indicator (blue dot)
  - [ ] Category badge (Important/To-Do/Newsletter/Spam)
  - [ ] Date/time

### Email Detail View
- [ ] Click an email → details appear
- [ ] Shows full sender email address
- [ ] Shows recipient address
- [ ] Shows email subject
- [ ] Shows full email body/content
- [ ] Shows category tag
- [ ] Shows "Mark Read" button
- [ ] "Mark Read" button works
- [ ] Mark as unread then read works

### Action Items Display
- [ ] Email with action items shows them
- [ ] Each action item shows:
  - [ ] Task description
  - [ ] Deadline date
  - [ ] Priority badge
- [ ] Checkbox can be clicked (if implemented)

### Prompts Tab
- [ ] Prompts tab loads
- [ ] Shows 4 default prompts:
  - [ ] Email Categorization
  - [ ] Action Item Extraction
  - [ ] Meeting Request Reply
  - [ ] Email Summary
- [ ] Each prompt shows:
  - [ ] Name
  - [ ] Type badge
  - [ ] Description
  - [ ] Preview of prompt text

### Create New Prompt
- [ ] "New Prompt" button visible
- [ ] Click opens prompt editor
- [ ] Name field works (can type)
- [ ] Type dropdown appears with options
- [ ] Description field works
- [ ] Prompt text area shows
- [ ] {email_content} hint appears
- [ ] "Save Prompt" button works
- [ ] New prompt appears in list
- [ ] Can see it after page refresh

### Agent Chat Tab
- [ ] Agent Chat tab loads
- [ ] Chat area visible
- [ ] Input field present at bottom
- [ ] "Send" button visible
- [ ] Can select an email from inbox
- [ ] Selected email shown in chat area

### Chat Functionality
- [ ] Type a question: "Summarize this email"
- [ ] Click Send or press Enter
- [ ] Message appears as user message
- [ ] Loading indicator appears
- [ ] AI responds after a few seconds
- [ ] Response appears as assistant message
- [ ] Can ask follow-up questions
- [ ] Drafts sidebar shows on right
- [ ] Message history persists in session

### Draft Management
- [ ] Drafts sidebar visible on right
- [ ] After AI generates content, check drafts
- [ ] Click "Use as Template" (if shown)
- [ ] Draft appears in sidebar
- [ ] Can scroll through drafts
- [ ] Each draft shows subject and preview

## API Verification

### Email API
- [ ] Open http://localhost:3000/api/emails in browser
- [ ] Should return JSON array
- [ ] Array contains email objects
- [ ] Each email has id, from, to, subject, body, etc.

### Prompts API
- [ ] Open http://localhost:3000/api/prompts in browser
- [ ] Should return JSON array
- [ ] Array contains prompt objects
- [ ] Has 4 default prompts

### Drafts API
- [ ] Open http://localhost:3000/api/drafts in browser
- [ ] Should return JSON array (may be empty)
- [ ] After saving draft, should have content

### Chat API
- [ ] Cannot test directly in browser (POST request)
- [ ] But should work through UI

## Data Persistence

### File Storage
- [ ] Check `data/` directory exists
- [ ] `data/emails.json` file exists
- [ ] `data/prompts.json` file exists
- [ ] `data/drafts.json` file exists
- [ ] Files contain valid JSON
- [ ] Can read file contents

### Data Refresh
- [ ] Refresh page (F5)
- [ ] Emails still appear
- [ ] Custom prompts still visible
- [ ] Drafts still saved

## Performance Checks

### Load Times
- [ ] Initial page load < 3 seconds
- [ ] Email list renders instantly
- [ ] Selecting email < 1 second
- [ ] Chat response 3-10 seconds (depends on OpenAI)

### Memory Usage
- [ ] Browser dev tools show < 100MB memory
- [ ] No memory leaks after interactions
- [ ] Page doesn't slow down over time

### Error Handling
- [ ] Type something in chat and send
- [ ] Try selecting email while typing
- [ ] Try rapid clicking
- [ ] No console errors
- [ ] App remains responsive

## Browser Compatibility

- [ ] Works in Chrome/Edge
- [ ] Works in Firefox (if available)
- [ ] Works in Safari (if on Mac)
- [ ] Responsive on different window sizes
- [ ] Mobile view works (if checking)

## Security Checks

### API Key
- [ ] `.env.local` is in `.gitignore` (not in repo)
- [ ] Key never appears in console output
- [ ] Key never visible in network requests
- [ ] Key only used server-side

### Data
- [ ] Emails stored locally (not sent anywhere)
- [ ] Drafts never auto-sent
- [ ] No unexpected API calls

## Error Scenarios

### Test Error Handling
1. **Stop the server** → Browser shows error
2. **Resume server** → Reconnects and works
3. **Bad API key** → Shows error message
4. **Network error** → Graceful fallback
5. **Select email without chat** → Works normally

## Advanced Checks (Optional)

### Code Quality
- [ ] No console errors or warnings
- [ ] TypeScript types visible (hover over variables)
- [ ] IDE autocomplete works
- [ ] Code is readable and commented

### Deployment Ready
- [ ] `npm run build` succeeds
- [ ] No build errors
- [ ] `npm start` runs production build
- [ ] Works on production port

### Database Backup (Future)
- [ ] Can export `data/` directory
- [ ] Can restore from backup
- [ ] All data recoverable

## Documentation Verification

- [ ] README.md exists and is readable
- [ ] SETUP_GUIDE.md has clear instructions
- [ ] FEATURES.md lists all features
- [ ] DEPLOYMENT.md has deployment options
- [ ] DEMO_VIDEO_GUIDE.md has video script
- [ ] PROJECT_SUMMARY.md is complete
- [ ] GETTING_STARTED.md is helpful
- [ ] This checklist file exists

## Final Smoke Tests

### Complete User Journey
1. [ ] Start fresh: delete `data/` directory
2. [ ] Run `npm run dev`
3. [ ] Page loads (data reinitializes)
4. [ ] Emails appear (from mock data)
5. [ ] Click an email
6. [ ] Go to Prompts tab
7. [ ] Create a new prompt
8. [ ] Go to Chat tab
9. [ ] Select email
10. [ ] Ask AI a question
11. [ ] AI responds
12. [ ] Check draft was saved
13. [ ] Everything works!

## Sign-Off

Once all items are checked:

- [ ] All core features work
- [ ] No critical errors
- [ ] Data persists correctly
- [ ] API responses valid
- [ ] Documentation complete
- [ ] Ready for use/deployment

## Notes

Use this space to document any issues or special notes:

\`\`\`
[Space for notes]


\`\`\`

## Resolution Guide

| Issue | Resolution |
|-------|-----------|
| Page won't load | Check npm run dev output, restart server |
| No emails appear | Check data/emails.json exists, restart |
| Chat not working | Verify OPENAI_API_KEY in .env.local |
| Prompts error | Check data/prompts.json is valid JSON |
| API 404 | Check API routes in app/api/ exist |
| TypeScript errors | Run npm install, check versions |
| Slow performance | Check system resources, close other apps |
| Data loss | Restore from data/ directory backup |

## Next Steps After Verification

✅ All checks pass:
1. Celebrate! 🎉
2. Read DEPLOYMENT.md to go live
3. Read DEMO_VIDEO_GUIDE.md to record demo
4. Share with others
5. Gather feedback
6. Customize for your needs

❌ Some checks fail:
1. Note which checks failed
2. Check SETUP_GUIDE.md troubleshooting
3. Check console for error messages
4. Verify .env.local configuration
5. Try restarting everything fresh
6. Review error logs

---

**Verification Complete!** ✨

Your Email Productivity Agent is ready to use!
