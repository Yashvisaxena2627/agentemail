# Email Productivity Agent - Setup Guide

## Quick Start (5 minutes)

### Step 1: Get Your OpenAI API Key

1. Visit https://platform.openai.com/api-keys
2. Sign in with your OpenAI account
3. Click "Create new secret key"
4. Copy the key (you won't see it again!)

### Step 2: Clone & Install

\`\`\`bash
# Clone the repository
git clone <your-repo-url>
cd email-agent

# Install dependencies
npm install
\`\`\`

### Step 3: Configure Environment

Create `.env.local` in the project root:

\`\`\`env
OPENAI_API_KEY=sk_your_actual_key_here_paste_it_here
\`\`\`

**Important:** Never share your API key! Never commit `.env.local` to Git.

### Step 4: Run the Application

\`\`\`bash
npm run dev
\`\`\`

The app will open at `http://localhost:3000`

### Step 5: Complete Setup

1. The app will automatically initialize:
   - Mock email inbox (10 sample emails)
   - Default prompt templates
   - Data storage directories

2. You'll see the setup page showing initialization progress

3. Click "Open Dashboard" when complete

## First Time Usage

### Loading Mock Inbox

The application automatically loads 10 sample emails on first run:
- 3 Important emails (meeting requests, reviews)
- 2 To-Do emails (action items)
- 3 Newsletter emails (updates)
- 2 Spam emails (promotions)

### Default Prompts Included

Four default prompts are pre-configured:
1. **Email Categorization** - Auto-sorts emails
2. **Action Item Extraction** - Finds tasks & deadlines
3. **Meeting Request Reply** - Drafts responses
4. **Email Summary** - Creates concise summaries

## Testing the System

### Test 1: View Emails

1. Go to **Inbox** tab
2. Click any email to view details
3. You'll see:
   - Email content
   - Automatic category
   - Extracted action items
   - Read/unread status

### Test 2: Create Custom Prompt

1. Go to **Prompts** tab
2. Click "New Prompt"
3. Fill in:
   - Name: "Test Prompt"
   - Type: "Custom"
   - Prompt: "Summarize in one sentence: {email_content}"
4. Click "Save Prompt"

### Test 3: Use AI Chat

1. Go to **Agent Chat** tab
2. Select an email
3. Try these prompts:
   - "Summarize this"
   - "Draft a reply"
   - "What tasks do I need?"
4. Watch the AI respond in real-time

### Test 4: Save Drafts

1. In the chat, generate a reply
2. Click "Use as Template" in the drafts sidebar
3. Drafts are saved but never sent

## Troubleshooting

### Issue: "OPENAI_API_KEY not found"

**Solution:** 
1. Check `.env.local` exists in project root
2. Verify the key is pasted correctly
3. Restart the development server: `npm run dev`

### Issue: Emails not loading

**Solution:**
1. Check browser console (F12) for errors
2. Verify data directory was created: `ls -la data/`
3. Ensure write permissions on the project folder
4. Try: `npm run dev` from a fresh terminal

### Issue: AI not responding

**Solution:**
1. Verify OpenAI API key is valid
2. Check your OpenAI account has credits at https://platform.openai.com/account/usage
3. Look at server logs for error messages (terminal running `npm run dev`)
4. Ensure stable internet connection

### Issue: "Port 3000 already in use"

**Solution:**
\`\`\`bash
# Use a different port
npm run dev -- -p 3001
# Then visit http://localhost:3001
\`\`\`

## Project Structure for Reference

\`\`\`
email-agent/
├── app/
│   ├── page.tsx              # Main dashboard
│   ├── setup/page.tsx        # Setup wizard
│   ├── layout.tsx            # Root layout
│   ├── globals.css           # Styles & theme
│   └── api/                  # Backend routes
│       ├── emails/
│       ├── prompts/
│       ├── drafts/
│       ├── process-email/
│       └── chat/
├── components/               # React components
│   ├── inbox.tsx
│   ├── email-detail.tsx
│   ├── email-agent.tsx
│   ├── prompt-configurator.tsx
│   └── ui/                   # UI components
├── lib/
│   ├── types.ts             # TypeScript types
│   ├── storage.ts           # File storage
│   └── mock-data.ts         # Sample data
├── data/                     # Auto-created storage
│   ├── emails.json
│   ├── prompts.json
│   └── drafts.json
└── package.json
\`\`\`

## Development

### Running Tests
\`\`\`bash
npm run test
\`\`\`

### Build for Production
\`\`\`bash
npm run build
npm run start
\`\`\`

### Code Quality
\`\`\`bash
npm run lint
\`\`\`

## Customization

### Add More Mock Emails

Edit `lib/mock-data.ts`:

\`\`\`typescript
export const mockEmails: Email[] = [
  // Add new emails here
  {
    id: '11',
    from: 'boss@company.com',
    to: 'you@example.com',
    subject: 'Your custom email',
    body: 'Your email content here',
    timestamp: new Date().toISOString(),
    category: 'Important',
    isRead: false,
  },
];
\`\`\`

### Customize Prompts

Edit `lib/mock-data.ts` and modify the `defaultPrompts` array, or create them via the UI.

### Change Theme Colors

Edit `app/globals.css` and modify the CSS variables in `:root` section.

## API Endpoints Reference

All endpoints return JSON.

### Emails
\`\`\`
GET /api/emails                    # Get all emails
PUT /api/emails                    # Update an email (send {id, updates})
\`\`\`

### Prompts
\`\`\`
GET /api/prompts                   # Get all prompts
POST /api/prompts                  # Create prompt (send prompt data)
PUT /api/prompts                   # Update prompt (send {id, updates})
\`\`\`

### Drafts
\`\`\`
GET /api/drafts                    # Get all drafts
POST /api/drafts                   # Create draft (send draft data)
PUT /api/drafts                    # Update draft (send {id, updates})
DELETE /api/drafts?id=<id>         # Delete draft
\`\`\`

### AI Processing
\`\`\`
POST /api/process-email            # Process email with LLM
POST /api/chat                     # Chat with email agent
\`\`\`

## Tips & Best Practices

1. **Test with Real Emails Later**
   - Currently uses mock inbox
   - Can be extended to connect to Gmail/Outlook

2. **Customize Prompts for Your Workflow**
   - Create specific prompts for your business domain
   - Test and refine based on results

3. **Review AI Outputs**
   - Always review drafts before sending
   - Adjust prompts if results aren't ideal

4. **Backup Your Data**
   - Periodically backup the `data/` directory
   - Contains all your emails, prompts, and drafts

5. **Monitor API Usage**
   - Check https://platform.openai.com/account/usage regularly
   - Set spending limits if needed

## Next Steps

1. Explore all features in the three tabs
2. Create custom prompts for your needs
3. Test the AI chat with different questions
4. Review and customize draft generation

## Need Help?

- **Check the README.md** for comprehensive documentation
- **Look at server logs** - Terminal running `npm run dev` shows errors
- **Check browser console** - Right-click → Inspect → Console tab
- **Review .env.local** - Make sure API key is set correctly

---

**You're all set!** Start managing your email productivity with AI. 🚀
