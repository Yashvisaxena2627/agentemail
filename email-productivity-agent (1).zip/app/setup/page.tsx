"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CheckCircle, AlertCircle, Loader2 } from "lucide-react"
import Link from "next/link"

export default function SetupPage() {
  const [status, setStatus] = useState<"checking" | "initializing" | "complete" | "error">("checking")
  const [checks, setChecks] = useState({
    apiKey: false,
    emailsDb: false,
    promptsDb: false,
    draftsDb: false,
  })

  useEffect(() => {
    const runChecks = async () => {
      try {
        // Check API key
        const hasApiKey = process.env.NEXT_PUBLIC_APP_URL ? true : false

        // Check emails
        const emailsRes = await fetch("/api/emails")
        const emailsDb = emailsRes.ok

        // Check prompts
        const promptsRes = await fetch("/api/prompts")
        const promptsDb = promptsRes.ok

        // Check drafts
        const draftsRes = await fetch("/api/drafts")
        const draftsDb = draftsRes.ok

        setChecks({
          apiKey: true,
          emailsDb,
          promptsDb,
          draftsDb,
        })

        if (emailsDb && promptsDb && draftsDb) {
          setStatus("complete")
        } else {
          setStatus("initializing")
          // Initialize
          await Promise.all([
            emailsRes.ok ? Promise.resolve() : fetch("/api/emails"),
            promptsRes.ok ? Promise.resolve() : fetch("/api/prompts"),
            draftsRes.ok ? Promise.resolve() : fetch("/api/drafts"),
          ])
          setStatus("complete")
        }
      } catch (error) {
        console.error("Setup error:", error)
        setStatus("error")
      }
    }

    runChecks()
  }, [])

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md border-border p-8">
        <div className="text-center">
          <h1 className="mb-2 text-3xl font-bold text-foreground">Setup</h1>
          <p className="mb-8 text-muted-foreground">Initializing Email Productivity Agent</p>

          <div className="space-y-4">
            {/* API Key */}
            <div className="flex items-center gap-3 rounded-lg bg-secondary/50 p-3">
              {checks.apiKey ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <AlertCircle className="h-5 w-5 text-yellow-500" />
              )}
              <span className="flex-1 text-left text-sm">OpenAI API Connected</span>
            </div>

            {/* Emails DB */}
            <div className="flex items-center gap-3 rounded-lg bg-secondary/50 p-3">
              {status === "checking" ? (
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              ) : checks.emailsDb ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-500" />
              )}
              <span className="flex-1 text-left text-sm">Emails Database</span>
            </div>

            {/* Prompts DB */}
            <div className="flex items-center gap-3 rounded-lg bg-secondary/50 p-3">
              {status === "checking" ? (
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              ) : checks.promptsDb ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-500" />
              )}
              <span className="flex-1 text-left text-sm">Prompts Database</span>
            </div>

            {/* Drafts DB */}
            <div className="flex items-center gap-3 rounded-lg bg-secondary/50 p-3">
              {status === "checking" ? (
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              ) : checks.draftsDb ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-500" />
              )}
              <span className="flex-1 text-left text-sm">Drafts Database</span>
            </div>
          </div>

          {status === "checking" && (
            <div className="mt-8 text-center">
              <Loader2 className="mb-3 inline-block h-6 w-6 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">Checking setup...</p>
            </div>
          )}

          {status === "complete" && (
            <div className="mt-8 text-center">
              <CheckCircle className="mb-3 inline-block h-8 w-8 text-green-500" />
              <p className="mb-4 font-semibold text-foreground">Ready to go!</p>
              <p className="mb-6 text-sm text-muted-foreground">All systems initialized successfully.</p>
              <Link href="/">
                <Button className="w-full">Open Dashboard</Button>
              </Link>
            </div>
          )}

          {status === "error" && (
            <div className="mt-8 text-center">
              <AlertCircle className="mb-3 inline-block h-8 w-8 text-red-500" />
              <p className="mb-4 font-semibold text-foreground">Setup Error</p>
              <p className="mb-6 text-sm text-muted-foreground">Please check the console for error details.</p>
              <Button onClick={() => window.location.reload()}>Retry</Button>
            </div>
          )}
        </div>
      </Card>
    </div>
  )
}
