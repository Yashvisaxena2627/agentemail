import { NextResponse } from "next/server"
import { getEmails, saveEmails } from "@/lib/storage"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { subject, body: emailBody, recipientEmail } = body

    if (!recipientEmail || !subject || !emailBody) {
      return NextResponse.json({ error: "Missing required fields: recipientEmail, subject, body" }, { status: 400 })
    }

    // Create a sent email object
    const sentEmail = {
      id: `sent-${Date.now()}`,
      from: "your-email@example.com", // This would be the user's email
      to: recipientEmail,
      subject: subject,
      body: emailBody,
      timestamp: new Date().toISOString(),
      category: "sent",
      isRead: true,
      type: "sent" as const,
      recipientEmail: recipientEmail,
      sentAt: new Date().toISOString(),
    }

    // Add to emails list
    const emails = getEmails()
    emails.push(sentEmail)
    saveEmails(emails)

    return NextResponse.json({
      success: true,
      message: `Email successfully sent to ${recipientEmail}`,
      email: sentEmail,
    })
  } catch (error) {
    console.error("Error sending email:", error)
    return NextResponse.json({ error: "Failed to send email. Please try again." }, { status: 500 })
  }
}
