import { NextResponse } from "next/server"
import { getEmails, saveEmails } from "@/lib/storage"
import { mockEmails } from "@/lib/mock-data"

export async function GET() {
  try {
    let emails = getEmails()

    // Initialize with mock data if empty
    if (emails.length === 0) {
      saveEmails(mockEmails)
      emails = mockEmails
    }

    return NextResponse.json(emails)
  } catch (error) {
    console.error("Error fetching emails:", error)
    return NextResponse.json({ error: "Failed to fetch emails" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { id, updates } = body

    const emails = getEmails()
    const index = emails.findIndex((e) => e.id === id)

    if (index === -1) {
      return NextResponse.json({ error: "Email not found" }, { status: 404 })
    }

    emails[index] = { ...emails[index], ...updates }
    saveEmails(emails)

    return NextResponse.json(emails[index])
  } catch (error) {
    console.error("Error updating email:", error)
    return NextResponse.json({ error: "Failed to update email" }, { status: 500 })
  }
}
