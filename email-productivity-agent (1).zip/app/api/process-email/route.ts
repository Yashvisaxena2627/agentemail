import { NextResponse } from "next/server"
import { generateText } from "ai"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { emailContent, prompt, action } = body

    if (!emailContent || !prompt) {
      return NextResponse.json({ error: "Email content and prompt are required" }, { status: 400 })
    }

    // Replace placeholder with actual email content
    const finalPrompt = prompt.replace("{email_content}", emailContent)

    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: finalPrompt,
      temperature: 0.5,
      maxTokens: 500,
    })

    // Try to parse JSON if action requires it
    let parsedResult = text
    if (action === "extract_actions" || action === "categorize") {
      try {
        parsedResult = JSON.parse(text)
      } catch {
        // If JSON parsing fails, return as string
        parsedResult = text
      }
    }

    return NextResponse.json({
      result: parsedResult,
      rawText: text,
      success: true,
    })
  } catch (error) {
    console.error("Error processing email:", error)
    return NextResponse.json({
      result: "Unable to process with LLM",
      rawText: "Error occurred during processing",
      success: false,
      fallback: true,
    })
  }
}
