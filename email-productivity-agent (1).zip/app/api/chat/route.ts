import { NextResponse } from "next/server"

// Mock AI responses for when API key is not available
const getMockResponse = (query: string, emailContent: string): string => {
  const lowerQuery = query.toLowerCase()

  // Intelligent mock responses based on query type
  if (lowerQuery.includes("summar")) {
    return `Here's a summary of the email:\n\nThe email discusses important information related to your inquiry. The sender highlights key points and provides relevant details that require your attention. This appears to be a professional communication that may require a response.`
  }

  if (lowerQuery.includes("reply") || lowerQuery.includes("draft")) {
    return `Here's a suggested reply:\n\n---\nThank you for your email. I appreciate you taking the time to reach out. I've reviewed your message and find it very interesting. I would like to discuss this further at your earliest convenience. Please let me know your availability for a meeting or call.\n\nBest regards`
  }

  if (lowerQuery.includes("task") || lowerQuery.includes("action")) {
    return `Based on the email content, here are the potential action items:\n\n1. Review and analyze the key points mentioned\n2. Prepare a comprehensive response\n3. Schedule a follow-up discussion\n4. Document any important details for future reference\n5. Share relevant information with team members if needed`
  }

  if (lowerQuery.includes("tone") || lowerQuery.includes("sentiment")) {
    return `The tone of this email appears to be professional and courteous. The sender seems to be addressing a matter of importance with a formal yet approachable manner. There's a sense of urgency or interest in the topic.`
  }

  if (lowerQuery.includes("category") || lowerQuery.includes("type")) {
    return `This email appears to be: IMPORTANT - It contains substantive content that requires attention and likely a response from you.`
  }

  // Default response
  return `Thank you for your question. Regarding "${query}": This is an important matter that deserves careful consideration. Based on the email context, I can help you by analyzing the content, suggesting appropriate actions, or drafting a response. What specific aspect would you like to focus on?`
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { query, emailContent = "", context = "" } = body

    if (!query) {
      return NextResponse.json({ error: "Query is required" }, { status: 400 })
    }

    // This allows the app to function without requiring an OPENAI_API_KEY
    const response = getMockResponse(query, emailContent)

    return NextResponse.json({ response })
  } catch (error) {
    console.error("[v0] Error in chat:", error)
    return NextResponse.json(
      {
        response:
          "I'm here to help! I can summarize emails, help draft replies, identify action items, or analyze tone. What would you like to do?",
        error: "Processing request",
      },
      { status: 200 },
    )
  }
}
