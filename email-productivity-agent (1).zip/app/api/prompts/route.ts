import { NextResponse } from "next/server"
import { getPrompts, savePrompts } from "@/lib/storage"
import { defaultPrompts } from "@/lib/mock-data"

export async function GET() {
  try {
    let prompts = getPrompts()

    // Initialize with default prompts if empty
    if (prompts.length === 0) {
      savePrompts(defaultPrompts)
      prompts = defaultPrompts
    }

    return NextResponse.json(prompts)
  } catch (error) {
    console.error("Error fetching prompts:", error)
    return NextResponse.json({ error: "Failed to fetch prompts" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const prompts = getPrompts()

    const newPrompt = {
      ...body,
      id: Date.now().toString(),
      isDefault: false,
      createdAt: new Date().toISOString(),
    }

    prompts.push(newPrompt)
    savePrompts(prompts)

    return NextResponse.json(newPrompt)
  } catch (error) {
    console.error("Error creating prompt:", error)
    return NextResponse.json({ error: "Failed to create prompt" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { id, updates } = body

    const prompts = getPrompts()
    const index = prompts.findIndex((p) => p.id === id)

    if (index === -1) {
      return NextResponse.json({ error: "Prompt not found" }, { status: 404 })
    }

    prompts[index] = { ...prompts[index], ...updates }
    savePrompts(prompts)

    return NextResponse.json(prompts[index])
  } catch (error) {
    console.error("Error updating prompt:", error)
    return NextResponse.json({ error: "Failed to update prompt" }, { status: 500 })
  }
}
