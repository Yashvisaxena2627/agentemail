import { NextResponse } from "next/server"
import { getDrafts, saveDrafts } from "@/lib/storage"
import type { Draft } from "@/lib/types"

export async function GET() {
  try {
    const drafts = getDrafts()
    return NextResponse.json(drafts)
  } catch (error) {
    console.error("Error fetching drafts:", error)
    return NextResponse.json({ error: "Failed to fetch drafts" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const drafts = getDrafts()

    const newDraft: Draft = {
      id: Date.now().toString(),
      subject: body.subject,
      body: body.body,
      tone: body.tone,
      category: body.category,
      createdAt: new Date().toISOString(),
      status: "draft",
      emailId: body.emailId,
      actionItems: body.actionItems,
    }

    drafts.push(newDraft)
    saveDrafts(drafts)

    return NextResponse.json(newDraft)
  } catch (error) {
    console.error("Error creating draft:", error)
    return NextResponse.json({ error: "Failed to create draft" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { id, updates } = body

    const drafts = getDrafts()
    const index = drafts.findIndex((d) => d.id === id)

    if (index === -1) {
      return NextResponse.json({ error: "Draft not found" }, { status: 404 })
    }

    drafts[index] = { ...drafts[index], ...updates }
    saveDrafts(drafts)

    return NextResponse.json(drafts[index])
  } catch (error) {
    console.error("Error updating draft:", error)
    return NextResponse.json({ error: "Failed to update draft" }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Draft ID required" }, { status: 400 })
    }

    const drafts = getDrafts()
    const filtered = drafts.filter((d) => d.id !== id)
    saveDrafts(filtered)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting draft:", error)
    return NextResponse.json({ error: "Failed to delete draft" }, { status: 500 })
  }
}
