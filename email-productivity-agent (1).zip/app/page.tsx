"use client"

import { useState, useEffect } from "react"
import { Sidebar } from "@/components/sidebar"
import { Inbox } from "@/components/inbox"
import { PromptConfigurator } from "@/components/prompt-configurator"
import { EmailAgent } from "@/components/email-agent"
import { EmailComposer } from "@/components/email-composer"
import { LoadingPage } from "@/components/loading-page"
import { Mail, AlertCircle, Plus, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

type TabType = "inbox" | "sent" | "starred" | "drafts" | "prompts" | "agent"

export default function Page() {
  const [activeTab, setActiveTab] = useState<TabType>("inbox")
  const [emails, setEmails] = useState([])
  const [selectedEmailId, setSelectedEmailId] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isComposerOpen, setIsComposerOpen] = useState(false)

  useEffect(() => {
    const loadEmails = async () => {
      try {
        setError(null)
        await new Promise((resolve) => setTimeout(resolve, 1200))
        const response = await fetch("/api/emails")
        if (!response.ok) throw new Error("Failed to fetch emails")
        const data = await response.json()
        setEmails(data)
      } catch (err) {
        console.error("Error loading emails:", err)
        setError("Failed to load emails. Using mock data.")
        setEmails([])
      } finally {
        setIsLoading(false)
      }
    }

    loadEmails()
  }, [isComposerOpen])

  const handleEmailSent = (newEmail: any) => {
    setEmails((prev) => [newEmail, ...prev])
    setActiveTab("inbox")
  }

  const getFilteredEmails = () => {
    const baseEmails = emails.filter((e: any) => {
      if (activeTab === "sent") return e.category === "sent" || e.type === "sent"
      if (activeTab === "starred") return e.starred === true
      if (activeTab === "drafts") return e.status === "draft"
      return e.category !== "sent" && e.type !== "sent"
    })
    return baseEmails
  }

  if (isLoading) {
    return <LoadingPage />
  }

  const filteredEmails = getFilteredEmails()

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />

      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="sticky top-0 z-40 border-b border-border bg-card dark:bg-card/50 shadow-sm">
          <div className="mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full gradient-green shadow-md">
                  <Mail className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 dark:from-emerald-400 dark:to-green-400 bg-clip-text text-transparent">
                    MailGenius
                  </h1>
                </div>
                <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-100 dark:bg-yellow-900/30 border border-yellow-300 dark:border-yellow-700 ml-4">
                  <Zap className="h-3 w-3 text-yellow-600 dark:text-yellow-500" />
                  <span className="text-xs font-semibold text-yellow-700 dark:text-yellow-400">Smart Mode</span>
                </div>
              </div>
              <Button
                onClick={() => setIsComposerOpen(true)}
                className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white shadow-lg transition-all"
              >
                <Plus className="h-4 w-4 mr-2" />
                Compose
              </Button>
            </div>
          </div>
        </header>

        {/* Error Alert */}
        {error && (
          <div className="mx-6 mt-4 flex items-center gap-3 rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/20 p-4">
            <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-500 flex-shrink-0" />
            <p className="text-sm text-amber-800 dark:text-amber-200">{error}</p>
          </div>
        )}

        {/* Content Area */}
        <main className="flex-1 overflow-auto p-6">
          {(activeTab === "inbox" || activeTab === "sent" || activeTab === "starred" || activeTab === "drafts") && (
            <Inbox
              emails={filteredEmails}
              onEmailSelect={setSelectedEmailId}
              selectedEmailId={selectedEmailId}
              onEmailsUpdate={setEmails}
            />
          )}
          {activeTab === "prompts" && <PromptConfigurator />}
          {activeTab === "agent" && <EmailAgent selectedEmailId={selectedEmailId} emails={emails} />}
        </main>
      </div>

      <EmailComposer isOpen={isComposerOpen} onClose={() => setIsComposerOpen(false)} onEmailSent={handleEmailSent} />
    </div>
  )
}
