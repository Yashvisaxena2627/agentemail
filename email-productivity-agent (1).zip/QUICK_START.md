# Email Agent - Quick Start (2 Minutes)

## Install & Run

\`\`\`bash
npm install
echo "OPENAI_API_KEY=sk_your_key_here" > .env.local
npm run dev
\`\`\`

Visit: http://localhost:3000

## First Steps

### 1. View Sample Emails
- Click **Inbox** tab
- See 10 pre-loaded sample emails
- Click any email to view details

### 2. Try Default Prompts
- Click **Prompts** tab
- See 4 built-in prompt templates
- Click pencil icon to view/edit

### 3. Chat with AI
- Click **Agent Chat** tab
- Select an email from inbox
- Ask a question:
  - "Summarize this"
  - "What should I do?"
  - "Draft a reply"
- Get AI response instantly

## Key Features

| Feature | How to Use |
|---------|-----------|
| Categorize Emails | Auto-applied to all emails |
| Extract Tasks | View in email detail under "Action Items" |
| Save Drafts | Ask AI in Agent Chat, drafts appear in sidebar |
| Create Prompts | Prompts Tab → New Prompt |
| Edit Prompts | Prompts Tab → Click pencil icon |
| Read Emails | Click email in list, view full content |
| Mark Read | Email Detail → "Mark Read" button |
| Copy Email | Email Detail → "Copy" button |

## Common Questions

**Q: Where is my data saved?**
A: All data is in your browser (localStorage). Clears if you clear browser cache.

**Q: Can it send emails?**
A: No! Drafts are for review only. Never auto-sends.

**Q: How do I add more emails?**
A: Create custom emails by modifying `lib/mock-data.ts` or manually add to localStorage.

**Q: Can I use with my email service?**
A: Currently uses mock inbox. Requires code changes for Gmail/Outlook integration.

**Q: What if API calls fail?**
A: System falls back to mock responses. Check API key and network.

## 5-Minute Tutorial

1. **Explore Inbox** (1 min)
   - Click Inbox tab
   - Browse 10 emails
   - Click one to see full details
   - Notice color-coded categories

2. **Try Agent Chat** (2 mins)
   - Go to Agent Chat tab
   - Select an email
   - Type: "Summarize this email"
   - Get instant AI response
   - Type: "Draft a professional reply"
   - See generated draft

3. **Create Custom Prompt** (2 mins)
   - Go to Prompts tab
   - Click "New Prompt"
   - Name: "Email Follow-up"
   - Type: "auto_reply"
   - Prompt: "If this is a business email, draft a professional follow-up asking for next steps."
   - Click "Save Prompt"
   - Use it in Agent Chat

## Default Emails Included

✉️ Q4 Project Kickoff  
✉️ Tech Blog Newsletter  
✉️ Proposal Review  
✉️ Promotional Offer  
✉️ Annual Review Notice  
✉️ Support Ticket Resolved  
✉️ Code Review Request  
✉️ Campaign Performance  
✉️ Enterprise Features  
✉️ OKR Discussion  

## Tips & Tricks

💡 **Pro Tips:**
- Use `{email_content}` in prompts as a placeholder
- Copy-paste email content for manual processing
- Create multiple prompts for different use cases
- Save useful drafts as templates
- Bookmark the app for quick access

⚡ **Speed Tips:**
- Press Enter to send chat message
- Click category badges to filter emails
- Use keyboard shortcuts: Tab to navigate, Enter to select
- Drag email list to scroll quickly

🎯 **Best Practices:**
- Start with default prompts before creating custom ones
- Test new prompts with sample emails first
- Keep prompt names short and descriptive
- Review AI-generated content before using
- Backup important prompts by copying to notes

## Customization Ideas

### Custom Prompts
- Sales follow-ups
- Customer support templates
- Project status updates
- Meeting summaries
- Code review feedback
- Travel booking confirmations

### Email Processing
- Auto-categorization rules
- Sentiment analysis
- Keyword extraction
- Priority scoring
- Response suggestion

## Next Steps

1. **Explore Features** - Spend 5 mins clicking around
2. **Create Custom Prompt** - Design one for your use case
3. **Generate Drafts** - Use AI to help write emails
4. **Save Templates** - Store useful responses
5. **Share** - Show colleagues/friends

## Troubleshooting

❌ **Not working?**
- Check console: Press F12 > Console tab
- Verify API key in `.env.local`
- Restart: `npm run dev`
- Clear cache: Ctrl+Shift+Delete

❌ **Chat not responding?**
- Refresh page
- Select a different email
- Check network in F12 > Network tab
- Verify OpenAI API credits

## Support

- 📖 Full guide: See `README.md`
- 🛠️ Setup help: See `SETUP_GUIDE.md`
- ❓ Troubleshooting: See `TROUBLESHOOTING.md`
- ✨ Features: See `FEATURES.md`

---

**Ready? Start at http://localhost:3000** ✨

Need help? Check the docs or browser console for details.
